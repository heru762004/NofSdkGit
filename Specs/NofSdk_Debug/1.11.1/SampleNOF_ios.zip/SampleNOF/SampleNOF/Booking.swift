//
//  Booking.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 2/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit

class Booking : Codable {
    var bookingDate: String
    var bookingTime: String
    var bookingAmount: String
    var bookingAuthCode: String
    var bookingRrn: String
    var bookingTid: String
    var bookingMid: String
    
    init() {
        bookingDate = ""
        bookingAmount = ""
        bookingAuthCode = ""
        bookingRrn = ""
        bookingTid = ""
        bookingTime = ""
        bookingMid = ""
    }
}
