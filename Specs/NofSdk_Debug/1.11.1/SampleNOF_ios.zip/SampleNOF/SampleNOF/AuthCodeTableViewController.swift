//
//  AuthCodeTableViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 29/5/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit
import Alamofire

class AuthCodeTableViewController: UITableViewController {

    #if SIT
    let MERCHANT_HOST_URL_CFA_PURCHASE = "https://nets.hopto.org/sit/nof/cfapurchase"
    #else
    let MERCHANT_HOST_URL_CFA_PURCHASE = "https://nfp-uat.nets.com.sg:9182/nof/cfapurchase"
    #endif
    
    var array_CFA_AuthCode: [String] = []
    var arrayCFA_TxnAmount: [String] = []
    let ARRAY_CFA = "ARRAY_CFA"
    let ARRAY_TXN_AMOUNT = "ARRAY_TXN_AMOUNT"
    var amount = ""
    var muid = ""
    var authCode = ""
    var selectedIdx: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = UserDefaults.standard
        array_CFA_AuthCode = defaults.array(forKey: ARRAY_CFA)  as? [String] ?? [String]()
        arrayCFA_TxnAmount = defaults.array(forKey: ARRAY_TXN_AMOUNT)  as? [String] ?? [String]()
        self.tableView.reloadData()
        print("amount = \(amount)")
        print("muid = \(muid)")
        print("array_CFA_AuthCode = \(array_CFA_AuthCode)")
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return array_CFA_AuthCode.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...
        let amount = arrayCFA_TxnAmount[indexPath.row]
        let c = (Double(amount)! / 100.0)
        
        cell.textLabel?.text = "\(array_CFA_AuthCode[indexPath.row]) - $\(c)"
        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = array_CFA_AuthCode[indexPath.row]
        self.authCode = data
        showAmountInputDialog()
        selectedIdx = indexPath.row
    }
    
    func doEndTrip(authCode: String) {
        let headers: HTTPHeaders = [
            "Accept": "application/json",
            "Content-Type": "application/json"
        ]
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        AF.request(MERCHANT_HOST_URL_CFA_PURCHASE, method: .post, parameters: ["amt": self.amount, "muid": muid, "muuid": muuid!, "authCode": authCode], encoding: JSONEncoding.default, headers: headers).debugLog().responseJSON {
            response in
            switch response.result {
            case .success:
                print(response)
                guard let respData = response.data else {
                    print("respData is nil")
                    return
                }
                print(respData)
                do {
                    let jsonResponse = try JSONSerialization.jsonObject(with:
                        respData) as! [String:Any]
                    
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
                        self.array_CFA_AuthCode.remove(at: self.selectedIdx)
                        self.arrayCFA_TxnAmount.remove(at: self.selectedIdx)
                        print("array_CFA_AuthCode = \(self.array_CFA_AuthCode)")
                        self.saveArrayToDB(keyName: self.ARRAY_CFA)
                        self.saveArrayToDB(keyName: self.ARRAY_TXN_AMOUNT)
                        self.tableView.reloadData()
                        self.showErrorMessage(errorCode: strResponseCode, errorMessage: "End Trip Success")
                    } else {
                        self.showErrorMessage(errorCode: strResponseCode, errorMessage: "End Trip failed")
                    }
                } catch let error {
                    print(error)
                    self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(error)")
                }
                break
            case .failure(let error):
                print(error)
                self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(error)")
            }
        }
        self.tableView.reloadData()
    }
    
    func showAmountInputDialog() {
        let alert = UIAlertController(title: "CFA Purchase", message: "Input Amount :", preferredStyle: .alert)
        
        //2. Add the text field. You can configure it however you need.
        alert.addTextField { (textField) in
            textField.keyboardType = UIKeyboardType.decimalPad
            textField.text = "1"
        }
        
        // 3. Grab the value from the text field, and print it when the user clicks OK.
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            guard let textField = alert?.textFields![0] else {
                return
            }
            guard let amount = textField.text else {
                return
            }
            let c = (Double(amount)! * 100.0)
            let d = Int(c)
            let b = String(format: "%012d", d)
            print("B = \(b)")
            self.amount = b
            
            self.doEndTrip(authCode: self.authCode)
            
        }))
        
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        if keyName == ARRAY_CFA {
            print("\(array_CFA_AuthCode) saved for \(keyName)")
            defaults.set(array_CFA_AuthCode, forKey: keyName)
        } else if keyName == ARRAY_TXN_AMOUNT {
            print("\(arrayCFA_TxnAmount) saved for \(keyName)")
            defaults.set(arrayCFA_TxnAmount, forKey: keyName)
        }
        defaults.synchronize()
    }
    
    func showErrorMessage(errorCode :String, errorMessage :String) {
        
        let alertController = UIAlertController(title: "Error : \(errorCode)", message: errorMessage, preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
        
    }
}
