//
//  TransactionHistory.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 27/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import Foundation

class TransactionHistory : Codable {
    var bookingDate: String
    var bookingTime: String
    var bookingAmount: String
    var bookingAuthCode: String
    var bookingRrn: String
    var bookingTid: String
    var bookingMid: String
    var purchased: Bool
    var statusTxn: String
    var refundTxn: [RefundTransaction]
    
    init() {
        bookingDate = ""
        bookingAmount = ""
        bookingAuthCode = ""
        bookingRrn = ""
        bookingTid = ""
        bookingTime = ""
        bookingMid = ""
        statusTxn = "PURCHASED"
        purchased = false
        refundTxn = [RefundTransaction]()
    }
    
    init (book: Booking, status: String = "PURCHASED") {
        bookingAmount = book.bookingAmount
        bookingDate = book.bookingDate
        bookingTime = book.bookingTime
        bookingAuthCode = book.bookingAuthCode
        bookingRrn = book.bookingRrn
        bookingTid = book.bookingTid
        bookingMid = book.bookingMid
        statusTxn = status
        purchased = true
        refundTxn = [RefundTransaction]()
    }
}
