//
//  SampleNOF.mm
//  SampleNOF
//
//  Created by Heru Prasetia on 29/7/19.
//  Copyright © 2019 NETS. All rights reserved.
//

#ifndef SampleNOF_h
#define SampleNOF_h

#import <QuartzCore/QuartzCore.h>
#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <objc/runtime.h>

@interface CLLocation(Swizzle)

@end

@implementation CLLocation(Swizzle)
static float x = -1;
static float y = -1;

static float controlOffsetX = 0;
static float controlOffsetY = 0;

CLLocationCoordinate2D pos;

+ (void) load {
    Method m1 = class_getInstanceMethod(self, @selector(coordinate));
    Method m2 = class_getInstanceMethod(self, @selector(coordinate_));
    
    method_exchangeImplementations(m1, m2);
    
    Method m3 = class_getInstanceMethod(self, @selector(onClientEventLocation));
    Method m4 = class_getInstanceMethod(self, @selector(onClientEventLocation_));
    
    method_exchangeImplementations(m3, m4);
    
    Method m5 = class_getInstanceMethod(self, @selector(setDelegate));
    Method m6 = class_getInstanceMethod(self, @selector(setDelegate_));
    
    method_exchangeImplementations(m5, m6);
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"_fake_x"]) {
        x = [[[NSUserDefaults standardUserDefaults] valueForKey:@"_fake_x"] floatValue];
    };
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"_fake_y"]) {
        y = [[[NSUserDefaults standardUserDefaults] valueForKey:@"_fake_y"] floatValue];
    };
    
}

-(void)setDelegate_:(id<CLLocationManagerDelegate>)delegate {
    [self setDelegate_:delegate];
}

- (CLLocationCoordinate2D) coordinate_ {
    
    pos = [self coordinate_];
    //Default location Times Square NYC
    if (x == -1 && y == -1) {
        x = pos.latitude - (40.758875);
        y = pos.longitude - (-73.985129);
        [[NSUserDefaults standardUserDefaults] setValue:@(x) forKey:@"_fake_x"];
        [[NSUserDefaults standardUserDefaults] setValue:@(y) forKey:@"_fake_y"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    return CLLocationCoordinate2DMake(pos.latitude+x + (controlOffsetX), pos.longitude+y + (controlOffsetY));
}

- (void)onClientEventLocation_:(id)foo {
    int i = 0;
    i++;
}

@end

#endif /* SampleNOF_h */
