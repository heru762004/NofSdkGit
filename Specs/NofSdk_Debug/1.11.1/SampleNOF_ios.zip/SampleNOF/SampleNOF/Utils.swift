//
//  Utils.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 20/4/20.
//  Copyright © 2020 NETS. All rights reserved.
//

import Foundation

class Utils {
    static func infoForKey(_ key: String) -> String? {
        let bundle = Bundle.main
        let config = (bundle.infoDictionary?[key] as? String)?.replacingOccurrences(of: "\\", with: "")
        return config
    }
    
    static func infoForKey(env: String, _ key: String) -> String? {
        let bundle = Bundle.main
        if (env == "SIT") {
            let configPath = bundle.path(forResource: "config_sit", ofType: "plist")!
            let config = NSDictionary(contentsOfFile: configPath)!
            return (config[key] as? String)?
                .replacingOccurrences(of: "\\", with: "")
        } else {
            // UAT
            let configPath = bundle.path(forResource: "config_uat", ofType: "plist")!
            let config = NSDictionary(contentsOfFile: configPath)!
            return (config[key] as? String)?
                .replacingOccurrences(of: "\\", with: "")
        }
        
    }
    
    static func configForKey(env: String) -> [Dictionary<String, String>]? {
        let bundle = Bundle.main
        if (env == "SIT") {
            let configPath = bundle.path(forResource: "midtid_sit", ofType: "plist")!
            let config = NSDictionary(contentsOfFile: configPath)!
            return (config["ListMerchant"] as? [Dictionary<String, String>])
        } else {
            // UAT
            let configPath = bundle.path(forResource: "midtid_uat", ofType: "plist")!
            let config = NSDictionary(contentsOfFile: configPath)!
            return (config["ListMerchant"] as? [Dictionary<String, String>])
        }
        
    }
}
