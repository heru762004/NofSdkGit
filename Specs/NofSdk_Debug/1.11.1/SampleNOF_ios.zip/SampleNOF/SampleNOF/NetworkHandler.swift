//
//  NetworkHandler.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 28/9/21.
//  Copyright © 2021 NETS. All rights reserved.
//

import Foundation
import UIKit

class NetworkHandler {
    public static func requestServer(json: [String: Any], req: URLRequest, completion: @escaping ([String: Any]?, Error?) -> Void) {
    
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        var request = req
        // create post request
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = ["Accept": "application/json",
                                       "Content-Type": "application/json"]
        // insert json data to the request
        request.httpBody = jsonData
        request.timeoutInterval = 60

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                completion(nil, error)
                return
            }
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            if let responseJSON = responseJSON as? [String: Any] {
                print(responseJSON)
                completion(responseJSON, nil)
            } else {
                completion(nil, NSError(domain: "invalidJSONTypeError", code: -100009, userInfo: nil))
            }
            
        }

        task.resume()
    }
}
