//
//  RefundTransaction.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 22/10/20.
//  Copyright © 2020 NETS. All rights reserved.
//

import Foundation

class RefundTransaction : Codable {
    var refundDate: String
    var refundTime: String
    var refundAmount: String
    var refundAuthCode: String
    var refundRrn: String
    var refundTid: String
    var refundMid: String
    var refundStatus: String
    
    init() {
        refundDate = ""
        refundTime = ""
        refundAmount = ""
        refundAuthCode = ""
        refundRrn = ""
        refundTid = ""
        refundMid = ""
        refundStatus = "REFUNDED"
    }
    
    init (book: Booking, status: String = "REFUNDED") {
        refundAmount = book.bookingAmount
        refundDate = book.bookingDate
        refundTime = book.bookingTime
        refundAuthCode = book.bookingAuthCode
        refundRrn = book.bookingRrn
        refundTid = book.bookingTid
        refundMid = book.bookingMid
        refundStatus = status
    }
}
