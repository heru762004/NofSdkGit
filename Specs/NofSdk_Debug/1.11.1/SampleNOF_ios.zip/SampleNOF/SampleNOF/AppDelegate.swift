//
//  AppDelegate.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 9/4/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit
//import Firebase

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    var window: UIWindow?
    
    
    #if PROD
    
    let HOST_URL                = "https://netspay.nets.com.sg"
    let API_GW_URL              = "https://api.nets.com.sg"
    
    let HPP_ISSUER_ID           = "0001"
    let HPP_ISSUER_ID_UOB       = "0002"
    let HPP_ISSUER_ID_OCBC      = "0003"
    let HPP_ISSUER_ID_SIM       = "9999"
    let APPLICATION_ID          = "00014000100"
    let APP_SECRET              = "B25C76857CED1EA60B331DAE4BDAB1E21D1EA1AF7314EB700FFD007892B0648A"
    
    
    
    let MAP_PUBLIC_KEY_ID       = "2"
    let MAP_PUBLIC_KEY_EXPONENT = "03"
    let MAP_PUBLIC_KEY_MODULUS  = "a8d687ac064ee2ce75a51a6351e1b4906366173bd53bba3dea9b8ee9cb57d8028b496cc860e3205f983afdac338b1f4a76a89ba4e832811cb6b8a581b961af256ba53f64cac3153a78922d5142667d5ca31766deb965f2f178e3e5622377d9fa24602e3e3d50bd82c40a9491065260c0f7bcef8a24425ae07acbde658caecb5d56ed2cd67f07bece6bdcefa733b8ab815c4c0d249f9d0784cd2a2a839ba650ae5359bc83b9c38539681603833ef05eeb6ca9b138b9abf3da592f443e6d90467d4a261864cc5de87d54cafcb4ed227e9c649674dd7bbdfd96c7ea25210216f0e7b484b00d39e019a62c8552b2f7b48f1b41be91e5f9262d6c4f75db39f5ea3f73"
    
    let HPP_PUBLIC_KEY_ID        = "4"
    let HPP_PUBLIC_KEY_EXPONENT  = "03"
    let HPP_PUBLIC_KEY_MODULUS   = "CA83F1C917C072B70757A6D88ED94C8E94AF7F142A2F8A52AC491243BF33F30C3FF18FEBED5D49AB5315057EBA3D3045D1B297F6893F2596CC08E6C5664F324993D553E690C48C9E7342673B3D94F167396E969017B0C80C980C3E8F8F32F28240ADBAA5AD4CA3619110575164738F50504C0CDA43A08B15F7D47A99F91DE2AE6773296C4794B56A989A1BF646FA5F2B3F03FAF20035CD0B0BF701FE977297B946100952BD07D7E73B6AC26B3964CB65831893690C8002B8568FAE0AEDF4DED213FEBCA081F4AEF5BE57B45C1C7EC98CF84D0F1CBCCEF707FDE8CC29821637F6E37653EC989D96AC18253DDC2FB2987616151EE6084653CAB85417A37E06FE1B"
    
    #endif


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
//        Fabric.with([Crashlytics.self])
        if #available(iOS 15, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor.lightGray
            UINavigationBar.appearance().standardAppearance = appearance;
            UINavigationBar.appearance().scrollEdgeAppearance = appearance
            UINavigationBar.appearance().isTranslucent = false
            
        }
        
        let HOST_URL = Utils.infoForKey("HOST_URL")!
        let API_GW_URL = Utils.infoForKey("API_GW_URL")!
        let ENV = Utils.infoForKey("ENV")!
        
        let HPP_ISSUER_ID = Utils.infoForKey(env: ENV, "HPP_ISSUER_ID")!
        let HPP_ISSUER_ID_UOB = Utils.infoForKey(env: ENV, "HPP_ISSUER_ID_UOB")!
        let HPP_ISSUER_ID_OCBC = Utils.infoForKey(env: ENV, "HPP_ISSUER_ID_OCBC")!
        let HPP_ISSUER_ID_SIM = Utils.infoForKey(env: ENV, "HPP_ISSUER_ID_SIM")!
        let APPLICATION_ID = Utils.infoForKey(env: ENV, "APPLICATION_ID")!
        let APP_SECRET = Utils.infoForKey(env: ENV, "APP_SECRET")!
        
        let MAP_PUBLIC_KEY_ID = Utils.infoForKey(env: ENV, "MAP_PUBLIC_KEY_ID")!
        let MAP_PUBLIC_KEY_EXPONENT = Utils.infoForKey(env: ENV, "MAP_PUBLIC_KEY_EXPONENT")!
        let MAP_PUBLIC_KEY_MODULUS  = Utils.infoForKey(env: ENV, "MAP_PUBLIC_KEY_MODULUS")!
        
        let HPP_PUBLIC_KEY_ID = Utils.infoForKey(env: ENV, "HPP_PUBLIC_KEY_ID")!
        let HPP_PUBLIC_KEY_EXPONENT = Utils.infoForKey(env: ENV, "HPP_PUBLIC_KEY_EXPONENT")!
        let HPP_PUBLIC_KEY_MODULUS   = Utils.infoForKey(env: ENV, "HPP_PUBLIC_KEY_MODULUS")!
        
        let mapPubKey = PublicKeyComponent(MAP_PUBLIC_KEY_ID,
                                           withKeyModulus: MAP_PUBLIC_KEY_MODULUS,
                                           withKeyExponent: MAP_PUBLIC_KEY_EXPONENT)
        
        let hppPubKey = PublicKeyComponent(HPP_PUBLIC_KEY_ID,
                                           withKeyModulus: HPP_PUBLIC_KEY_MODULUS,
                                           withKeyExponent: HPP_PUBLIC_KEY_EXPONENT)
        
//        if ENV == "SIT" {
//            let HPP_PUBLIC_KEY_ID_UOB = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_ID_UOB")!
//            let HPP_PUBLIC_KEY_MODULUS_UOB = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_MODULUS_UOB")!
//            let HPP_PUBLIC_KEY_EXPONENT_UOB = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_EXPONENT_UOB")!
//
//            let HPP_PUBLIC_KEY_ID_OCBC = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_ID_OCBC")!
//            let HPP_PUBLIC_KEY_MODULUS_OCBC = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_MODULUS_OCBC")!
//            let HPP_PUBLIC_KEY_EXPONENT_OCBC = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_EXPONENT_OCBC")!
//
//            let HPP_PUBLIC_KEY_ID_SIM = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_ID_SIM")!
//            let HPP_PUBLIC_KEY_MODULUS_SIM = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_MODULUS_SIM")!
//            let HPP_PUBLIC_KEY_EXPONENT_SIM = Utils.infoForKey(env: ENV,"HPP_PUBLIC_KEY_EXPONENT_SIM")!
//
//            let hppPubKey_uob = PublicKeyComponent(HPP_PUBLIC_KEY_ID_UOB,
//                                                   withKeyModulus: HPP_PUBLIC_KEY_MODULUS_UOB,
//                                                   withKeyExponent: HPP_PUBLIC_KEY_EXPONENT_UOB)
//            
//            let hppPubKey_ocbc = PublicKeyComponent(HPP_PUBLIC_KEY_ID_OCBC,
//                                                    withKeyModulus: HPP_PUBLIC_KEY_MODULUS_OCBC,
//                                                    withKeyExponent: HPP_PUBLIC_KEY_EXPONENT_OCBC)
//            
//            let hppPubKey_sim = PublicKeyComponent(HPP_PUBLIC_KEY_ID_SIM,
//                                                   withKeyModulus: HPP_PUBLIC_KEY_MODULUS_SIM,
//                                                   withKeyExponent: HPP_PUBLIC_KEY_EXPONENT_SIM)
//        }

//        let dic: NSMutableDictionary = [HPP_ISSUER_ID: hppPubKey, HPP_ISSUER_ID_SIM: hppPubKey_sim, HPP_ISSUER_ID_UOB: hppPubKey_uob, HPP_ISSUER_ID_OCBC: hppPubKey_ocbc]
        
        let dic: NSMutableDictionary = [HPP_ISSUER_ID: hppPubKey, HPP_ISSUER_ID_SIM: hppPubKey, HPP_ISSUER_ID_UOB: hppPubKey, HPP_ISSUER_ID_OCBC: hppPubKey]
        
        let pks = PublicKeySet(mapPubKey, withHppPublicComponents: dic)
        
        var serverName: NSMutableArray = ["netspayserver_test"]
        #if PROD
            serverName = "netspay_nets_com_sg"
        #endif
        DispatchQueue.global().async() {
            do {
                try ExceptionCatcher.catchException {
                    NofService.main().setSdkDebuggable(true)
                    NofService.main().initialize(withServerBaseUrl: HOST_URL, withApiGwBaseUrl: API_GW_URL, withAppId: APPLICATION_ID, withAppSecret: APP_SECRET, with: pks, withServerCertNames: serverName, success: { (result) in
                        DispatchQueue.main.async() {
                            print("result success = \(result)")
                            self.gotoNextScreen()
                            
                        }
                    }, failure: { (errorCode) in
                        DispatchQueue.main.async() {
                            print("failed \(errorCode)")
                            //self.gotoNextScreen()
                            self.showAlert(message: "Initialization failed : \(errorCode)")
                        }
                    })
                }
            } catch {
                print("ERROR = \(error)")
                let err: NSError = error as NSError
//                if error.localizedDescription == ServiceError.serviceAlreadyInitializedException().name.rawValue {
//                    print(error.localizedDescription)
//                }
                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                    print(error.localizedDescription)
                }
                if error.localizedDescription == ServiceError.missingServerCertException().name.rawValue {
                    print(error.localizedDescription)
                    DispatchQueue.main.async() {
                        self.showAlert(message: "Service Initialized Error : Missing Cert")
                    }
                }
                if error.localizedDescription == ServiceError.missingDataException("").name.rawValue {
                    print(error.localizedDescription)
                    if let missingFields: String = err.userInfo["NSLocalizedDescriptionKey"] as? String {
                        DispatchQueue.main.async() {
                            self.showAlert(message: "Missing Data : \(missingFields)")
                        }
                    }
                }
                if error.localizedDescription == ServiceError.serviceNotInitializedException("").name.rawValue {
                    print(error.localizedDescription)
                    if let missingFields: String = err.userInfo["NSLocalizedDescriptionKey"] as? String {
                        DispatchQueue.main.async() {
                            self.showAlert(message: "Service Initialized Error : \(missingFields)")
                        }
                    }
                }
//                DispatchQueue.main.async() {
//                    self.gotoNextScreen()
//                }
            }
        }
        return true
    }
    
    func gotoNextScreen() {
//        FirebaseApp.configure()
//        FirebaseConfiguration.shared.setLoggerLevel(.max)
//
//        Crashlytics.crashlytics().setCrashlyticsCollectionEnabled(true)
//
//        Crashlytics.crashlytics().checkForUnsentReports { _ in
//            Crashlytics.crashlytics().sendUnsentReports()
//        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            let isChoosed = self.getDataFromDB(keyName: self.IS_CHOOSE_TYPE)
            if (isChoosed == "") {
                let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationMain") as! UINavigationController
                let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationType") as! UINavigationController
                self.window?.rootViewController = exampleViewController
                
                self.window?.makeKeyAndVisible()
            } else {
                if (isChoosed == "CFA") || (isChoosed == "0") {
                    // go to ride hailing
                    let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationMain") as! UINavigationController
                    //                let navigationController = UINavigationController(rootViewController: exampleViewController)
                    self.window?.rootViewController = exampleViewController
                    
                    self.window?.makeKeyAndVisible()
                    
                } else if (isChoosed == "DEBIT") {
                    // go to nets telco
                    
                    let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationTelco") as! UINavigationController
                    
                    self.window?.rootViewController = exampleViewController
                    
                    self.window?.makeKeyAndVisible()
                }
                
                
            }
        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message:message, preferredStyle: .alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        // show the alert
        self.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

