//
//  ViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 9/4/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    #if SIT
    let MERCHANT_HOST_URL       = "https://nets.hopto.org/sit/nof/gmt"
    let MERCHANT_HOST_URL_CFA   = "https://nets.hopto.org/sit/nof/cfa"
    let MERCHANT_HOST_URL_CFA_PURCHASE = "https://nets.hopto.org/sit/nof/cfapurchase"
    let MERCHANT_HOST_URL_DIRECT_PURCHASE = "https://nets.hopto.org/sit/nof/purchase"
    #else
    let MERCHANT_HOST_URL       = "https://nfp-uat.nets.com.sg:9182/nof/gmt"
    let MERCHANT_HOST_URL_CFA   = "https://nfp-uat.nets.com.sg:9182/nof/cfa"
    let MERCHANT_HOST_URL_CFA_PURCHASE = "https://nfp-uat.nets.com.sg:9182/nof/cfapurchase"
    let MERCHANT_HOST_URL_DIRECT_PURCHASE = "https://nfp-uat.nets.com.sg:9182/nof/purchase"
    #endif
    
    let HOST_URL                = "http://118.201.98.228:8080"
    let API_GW_URL              = "https://uat-api.nets.com.sg"
    //internal ip HCESIT
//    let HOST_URL                = "http://172.18.20.146:7201/mapserver/txn"
    
    let KEY_REQUEST_URL         = "https://uat-api.nets.com.sg/sit/paymentservices/nof/v1/keyrequest"
    let PIN_SUBMISSION_URL      = "https://uat-api.nets.com.sg/sit/paymentservices/nof/v1/pinblocksubmission"
    
    let HPP_ISSUER_ID           = "0001"
    let HPP_ISSUER_ID_UOB       = "0002"
    let HPP_ISSUER_ID_OCBC      = "0003"
    let HPP_ISSUER_ID_SIM       = "9999"
    let APPLICATION_ID          = "00012222222"
    let APP_SECRET              = "C4C2BEA4BA1E6596DF6AE3684C8CD752EC96E0B854CE143B4FF6DF13B8719BC4"
    
    /**
     // FORCE UPDATE TEST
     let APPLICATION_ID          = "00010000100"
     let APP_SECRET              = "E0055EBF93F18665F56ED4A07BB04F1A3D168CC69892AB4CAC0DBFEE4142DFA6"
     */
    
    
    let MAP_PUBLIC_KEY_ID       = "1"
    let MAP_PUBLIC_KEY_EXPONENT = "03"
    let MAP_PUBLIC_KEY_MODULUS  = "c2b5e3e7ee6731a22630a9c76634e9b4a53212198cf2cc08627c0069a0e849ca30351e71cbf4a7926bee2f3cec88c257b6a1512f79e10604a959a5981cc99b8656880b944fc71e0bd0dce6c66b03763720a09eb8336f8dc68b6c4ad175bf92d738a5fb095ab998bfd89dcea400ffb13f8165861146ca8c20fdb4cd1be0c99f449693b868070916602e07f45477fffb890f7c13352169175b08e88add1a1c785790d940b8b68f629d6f7a98d5cc0ef29c54e575d2cc9ee39e87341e2b21950e302ac67178ff0f6d8b8b16d6cb57a6b7637e9bc03a48f24310e86895f42210dfdb5b4d2ab3566df45e7897551b40353ffe166f6242fbd63b33e1c494ab801f3b7b"
    
    // DBS
    let HPP_PUBLIC_KEY_ID        = "1"
    let HPP_PUBLIC_KEY_EXPONENT  = "03"
    let HPP_PUBLIC_KEY_MODULUS   = "D0B8E92576E3CEC934A186132127008139D24915D85A85901197F9C163B5E3C68A284D3F4ED3CC22A7EF76895A0BF986668A9FB17F239200C04ED3CBC6F243FFBF801052E8F0E61F29FC9F05FF2A0CC5E85C187A7F0F8AC3FCC897FBAEC2A123D4C1F94C7360EA874873A1E487EA0F81240A5A2F31AA8AA50AD92ED2758FBC8414E30B8DC06CF05145BF7A2519DAE09ACCFBA32B3E198DC73C02EA29F4516FE92D18EAAA021809B1B8BDBC120F5F65C9C3B84AE4F561C448AF347B6015278EDF000448A9486283253F7DCF5C8CFD7EE614291473369FC3BF07BE9B40449BF1C0ACBA164F205C57C36AF7493BE3DD479ACC16067D159CC3A2658DD7EF2E80297F"
    
    // UOB
    let HPP_PUBLIC_KEY_ID_UOB = "2"
    let HPP_PUBLIC_KEY_EXPONENT_UOB = "03"
    let HPP_PUBLIC_KEY_MODULUS_UOB = "A7D87958677A63C8935D7949E0FC79C65155312D882CCF84028FE824ED721819543EF18176219E82BC2F097FACA0F90BB877C1A251463F2049D6B926BF561F9D182E7D28752EDEB08DA593FB1FE63BEF65BD9D064DB157CFB9F3D1BDCB638B293FAEED24AC95A14BCE89FB416E3993FE0D8E11F67D13C137AE5C6789EE0F4D077929B6D3726C59AD5C7FB0EFB3A5A28F319CF81619F8B18B0106DC7CDCFDCFB8334B2336AA96D7DD6FCA20ABC86FF3AC4DB46450D4DC36A07FC241DABF8693545973B9EF276ED1DF799E56EC4B0031CBDCE7F11BB9E7BE74899700F86DAB5CF9FDFC7DDE8E43EC6B946055EB479E00CE8972E370FF806BD67161C8D4CCF6E4BF"
    
    // OCBC
    let HPP_PUBLIC_KEY_ID_OCBC = "4"
    let HPP_PUBLIC_KEY_EXPONENT_OCBC = "03"
    let HPP_PUBLIC_KEY_MODULUS_OCBC = "9FC25DC90D47B5830A9C28504C1C255CC4D3B0AC76F6E2D0DD053CBEDB9AF42DE2A5F407290D3F83CAEB92C5642DE94F729F9ADCC29414C6FE5B507A7EB06D5C71F822AE133A864FC8D02959CB1E93CF138C531B1B678E15B924C41E5E56240AC0E8B6BB9DA4A8397C5332A34D379872CD838AA149E59B6A5417644DB4C379338FCF8131610826FFCE7DE09D8DBCBA5EB305B8E6C96D4D6F846675C0BD73CF05973C1732BB44B3E8CBFA8CA8805956288BBE1C3E5C2D1796445D990F3BA5EDA620077621C669D6F4D197DC9128DBE93BA263977BD686955574CB57A0EB607E80F30870785106C19D9D99DF9980A222D2DC67C53708F30458392723967794FA5F"
    
    let HPP_PUBLIC_KEY_ID_SIM = "9"
    let HPP_PUBLIC_KEY_EXPONENT_SIM = "03"
    let HPP_PUBLIC_KEY_MODULUS_SIM = "BAF2BC7627866D0C28D816CCF28DA80A4D64950435670449821F8EB5A4754D29334CF69320A90393A73A9B2BAD1BE94D97CA2D0C0E692ABD5532FE5893E1CD3A05A4AD57D8A88E7B6C6A6AC420DE216A5F87194CD812088721591E95CF28642715C9C25358110FEF859EC2FC6DBFE849DF225D77E9CF6BCA65A99E6241D3217C767A4396A6894BE54E9868B35B67F0B0C3085CD083DEECD91069277EACE6A94A3B133C5D1269FF75D43C8936536E7A24EC5ED650EE759D4B0C6EB44838E08BB2ECFE385660FFEB2E9FA3B8ED9FA91AF3148327620279FD2E360DC59797B07903987D0DBB0F20D0393DA131D3EEF7BE5B85683AA327B9BCCBCBD9F92E7DE49189"
    
    
    // comfort RID : "11181300100"
    // master RID : "11180000100"
    let mid = "11181300100"
//    var muid = "hp166@yahoo.com"
    var muid = "hp145@yahoo.com"
//    let muid = "user12@yahoo.com"
    
    let serverName = "netspayserver"
    
    let TXN_CFA = 1
    let TXN_DEBIT = 2
    
    var table0102 = ""
    var table0205 = ""
    
    var arrayCFA_AuthCode: [String] = []
    var arrayCFA_TxnAmount: [String] = []
    let ARRAY_CFA = "ARRAY_CFA"
    let ARRAY_TXN_AMOUNT = "ARRAY_TXN_AMOUNT"
    
    @IBOutlet weak var txtMid: UITextField!
    @IBOutlet weak var txtMuid: UITextField!
    @IBOutlet weak var txtAmount: UITextField!
    
    var amount = "000000000100"
//    let amount = "000000030000"
    
    override func viewDidLoad() {
        self.txtMid.text = mid;
        self.txtMuid.text = muid;
        
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        amount = "1.0"
        self.txtAmount.text = amount
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func initService() {
        let mapPubKey = PublicKeyComponent(MAP_PUBLIC_KEY_ID,
                                           withKeyModulus: MAP_PUBLIC_KEY_MODULUS,
                                           withKeyExponent: MAP_PUBLIC_KEY_EXPONENT)
        
        let hppPubKey = PublicKeyComponent(HPP_PUBLIC_KEY_ID,
                                           withKeyModulus: HPP_PUBLIC_KEY_MODULUS,
                                           withKeyExponent: HPP_PUBLIC_KEY_EXPONENT)
        
        let hppPubKey_uob = PublicKeyComponent(HPP_PUBLIC_KEY_ID_UOB,
                                               withKeyModulus: HPP_PUBLIC_KEY_MODULUS_UOB,
                                               withKeyExponent: HPP_PUBLIC_KEY_EXPONENT_UOB)
        
        let hppPubKey_ocbc = PublicKeyComponent(HPP_PUBLIC_KEY_ID_OCBC,
                                                withKeyModulus: HPP_PUBLIC_KEY_MODULUS_OCBC,
                                                withKeyExponent: HPP_PUBLIC_KEY_EXPONENT_OCBC)
        
        let hppPubKey_sim = PublicKeyComponent(HPP_PUBLIC_KEY_ID_SIM,
                                               withKeyModulus: HPP_PUBLIC_KEY_MODULUS_SIM,
                                               withKeyExponent: HPP_PUBLIC_KEY_EXPONENT_SIM)
        
        let dic: NSMutableDictionary = [HPP_ISSUER_ID: hppPubKey, HPP_ISSUER_ID_SIM: hppPubKey_sim, HPP_ISSUER_ID_UOB: hppPubKey_uob, HPP_ISSUER_ID_OCBC: hppPubKey_ocbc]
        
        let pks = PublicKeySet(mapPubKey, withHppPublicComponents: dic)
        
        self.showLoading()
        
        let serverName = "netspayserver"
        
        DispatchQueue.global().async() {
            do {
                try ExceptionCatcher.catchException {
                    NofService.main().initialize(withServerBaseUrl: self.HOST_URL, withApiGwBaseUrl: self.API_GW_URL, withAppId: self.APPLICATION_ID, withAppSecret: self.APP_SECRET, with: pks, withServerCertName: serverName, success: { (result) in
                        DispatchQueue.main.async() {
                            print("result success = \(result)")
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(errorCode: result, errorMessage: "")
                            })
                        }
                    }, failure: { (errorCode) in
                        DispatchQueue.main.async() {
                            print("failed \(errorCode)")
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(errorCode: errorCode, errorMessage: "")
                            })
                        }
                    })
                }
            } catch {
                print("ERROR = \(error)")
//                if error.localizedDescription == ServiceError.serviceAlreadyInitializedException().name.rawValue {
//                    print("Service Already initialized = \(error.localizedDescription)")
//                }
                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                    print(error.localizedDescription)
                }
                if error.localizedDescription == ServiceError.missingServerCertException().name.rawValue {
                    print(error.localizedDescription)
                }
                DispatchQueue.main.async() {
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                    })
                }
            }
            
        }
    }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[CardPinViewController] : \(#function)")
        self.view.endEditing(true)
    }

    @IBAction func doInitServicew(_ sender: Any) {
        self.initService()
    }
    
    @IBAction func doOldRegistration(_ sender: Any) {
//        let oldReg = OldRegistration(mobileNumber: "+6583715554", "heruprasetia@nets.com.sg")
//        do {
//            try ExceptionCatcher.catchException {
//                self.showLoading()
//                oldReg.invoke({ (result) in
//                    print("result success = \(result)")
//                    self.hideLoading()
//                }, failure: { (error) in
//                    print("failed")
//                    self.hideLoading()
//                })
//            }
//        } catch {
//            print(error.localizedDescription)
//            self.hideLoading()
////            if error.localizedDescription == ServiceError.serviceNotInitializedException().reason {
////
////            }
//        }
    }
    
    @IBAction func doRegister(_ sender: Any) {
        guard let midStr = self.txtMid.text else {
            return;
        }
        
        guard let muidStr = self.txtMuid.text else {
            return;
        }
        let reg = Registration(viewController: self, withMuid: muidStr, andWithMid: midStr)
        do {
            try ExceptionCatcher.catchException {
               // self.showLoading()
                DispatchQueue.global().async() {
                    reg.invoke({ (result) in
                        DispatchQueue.main.async() {
                            print("result success = \(result)")
                            self.table0102 = result;
                            UserDefaults.standard.set(self.table0102, forKey: "table0102")
                            self.showErrorMessage(errorCode: "00", errorMessage: "registration success")
                        }
                        //   self.hideLoading()
                    }, failure: { (error) in
                        DispatchQueue.main.async() {
                            self.showErrorMessage(errorCode: error, errorMessage: "registration failed")
                            print("failed responseCode = " + error)
                        }
                        // self.hideLoading()
                    })
                }
            }
        } catch {
            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                print(error.localizedDescription)
            }
            DispatchQueue.main.async() {
                self.dismiss(animated: true, completion: {
                    self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                })
            }
        }
    }
    
    @IBAction func doGetMerchantToken(_ sender: Any) {
        
//        let myURL = URL(string: MERCHANT_HOST_URL)!
//        let request = NSMutableURLRequest(url: myURL)
//        request.httpMethod = "POST"
//        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
//        if let c = UserDefaults.standard.string(forKey: "table0102") {
//            print("C = \(c)" )
//            request.httpBody = c.data(using: String.Encoding.utf8);
//            self.showLoading()
//            let task = URLSession.shared.dataTask(with: request as URLRequest) {
//                data, response, error in
//                print("RESPONSE = \(response)")
//                if let dt = data {
//                    let returnData = String(data: dt, encoding: .utf8)
//                    print("DATA = \(returnData)")
//                }
//                self.hideLoading()
//                // Your completion handler code here
//            }
//            task.resume()
//        }
        
        
        
        let headers: HTTPHeaders = [
            "Accept": "application/json",
            "Content-Type": "application/json"
        ]
        if let c = UserDefaults.standard.string(forKey: "table0102") {
            self.showLoading()
            let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
            guard let muidStr = self.txtMuid.text else {
                return;
            }
            AF.request(MERCHANT_HOST_URL, method: .post, parameters: ["t0102": c, "muid": muidStr, "muuid": muuid!], encoding: JSONEncoding.default, headers: headers).debugLog().responseJSON {
                response in
                switch response.result {
                case .success:
                    
                    print(response)
                    guard let respData = response.data else {
                        print("respData is nil")
                        return
                    }
                    do {
                        let jsonResponse = try JSONSerialization.jsonObject(with:
                            respData) as! [String:Any]
                        
                        guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                            return
                        }
                        var message = ""
                        if strResponseCode == "00" {
                            message = "SUCCESS"
                        }
                        DispatchQueue.main.async() {
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(errorCode: strResponseCode, errorMessage: message)
                            })
                        }
                    } catch let error {
                        print(error)
                    }
                    
                    break
                case .failure(let error):
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: error.localizedDescription)
                    })
                    print(error)
                }
            }
        }
    }
    
    @IBAction func doDeRegistration(_ sender: Any) {
        let dereg = Deregistration()
        do {
            try ExceptionCatcher.catchException {
                self.showLoading()
                dereg.invoke({ (result) in
                    print("result success = \(result)")
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: "00", errorMessage: "Deregistration success")
                    })
                }, failure: { (error) in
                    print("failed responseCode = " + error)
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: error, errorMessage: "Deregistration failed")
                    })
                    
                })
            }
        } catch {
            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                print(error.localizedDescription)
            }
            DispatchQueue.main.async() {
                self.dismiss(animated: true, completion: {
                    self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                })
            }
        }
    }
    
    func submitCFA(amount: String, txnType: Int) {
        let headers: HTTPHeaders = [
            "Accept": "application/json",
            "Content-Type": "application/json"
        ]
        var url = MERCHANT_HOST_URL_CFA
        if txnType == TXN_DEBIT {
           url = MERCHANT_HOST_URL_DIRECT_PURCHASE
        }
        guard let muidStr = self.txtMuid.text else {
            return;
        }
//        uuid = [[[[UIDevice currentDevice] identifierForVendor] UUIDString] stringByReplacingOccurrencesOfString:@"-" withString:@""];
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        if let c = UserDefaults.standard.string(forKey: "table0205") {
            self.showLoading()
            AF.request(url, method: .post, parameters: ["t0205": c, "amt": amount, "muid": muidStr, "muuid": muuid!], encoding: JSONEncoding.default, headers: headers).debugLog().responseJSON {
                response in
                switch response.result {
                case .success:
                    print(response)
                    guard let respData = response.data else {
                        print("respData is nil")
                        return
                    }
                    do {
                        let jsonResponse = try JSONSerialization.jsonObject(with:
                            respData) as! [String:Any]

                        guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                            return
                        }
                        guard let strT53: String = jsonResponse["t5253"] as? String else {
                            return
                        }
                        guard let strAuthCode: String = jsonResponse["authCode"] as? String else {
                            return
                        }
                        if strResponseCode == "00" {
//                            if table53.count == 183 {
//                                table53 = table53.starts(with: 78)
//                            }
                            let defaults = UserDefaults.standard
                            self.arrayCFA_AuthCode = defaults.array(forKey: self.ARRAY_CFA)  as? [String] ?? [String]()
                            self.arrayCFA_TxnAmount = defaults.array(forKey: self.ARRAY_TXN_AMOUNT) as? [String] ?? [String]()
                            self.arrayCFA_AuthCode.append(strAuthCode)
                            self.arrayCFA_TxnAmount.append(self.amount)
                            self.saveArrayToDB(keyName: self.ARRAY_CFA)
                            self.saveArrayToDB(keyName: self.ARRAY_TXN_AMOUNT)
                        }
                        self.handleResponsePurchase(respCode: strResponseCode, t53: strT53, txnType: txnType)
                    } catch let error {
                        print(error)
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(error)")
                        })
                        
                    }
                    break
                case .failure(let error):
                    print(error)
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(error)")
                    })
                    
                }
            }
        }
        
        
//        let myURL = URL(string: MERCHANT_HOST_URL_CFA)!
//        let request = NSMutableURLRequest(url: myURL)
//        request.httpMethod = "POST"
//        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
//        if let c = UserDefaults.standard.string(forKey: "table05") {
//            print("C = \(c)" )
//            request.httpBody = c.data(using: String.Encoding.utf8);
//            self.showLoading()
//            let task = URLSession.shared.dataTask(with: request as URLRequest) {
//                data, response, error in
//                print("RESPONSE = \(response)")
//                if let dt = data {
//                    let returnData = String(data: dt, encoding: .utf8)
//                    print("DATA = \(returnData)")
//                }
//                self.hideLoading()
//                // Your completion handler code here
//            }
//            task.resume()
//        }
    }
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        if keyName == ARRAY_CFA {
            print("\(arrayCFA_AuthCode) saved for \(keyName)")
            defaults.set(arrayCFA_AuthCode, forKey: keyName)
        } else if keyName == ARRAY_TXN_AMOUNT {
            print("\(arrayCFA_TxnAmount) saved for \(keyName)")
            defaults.set(arrayCFA_TxnAmount, forKey: keyName)
        }
        defaults.synchronize()
    }
    
    func handleResponsePurchase(respCode: String, t53: String, txnType: Int) {
        if respCode == "U9" || respCode == "55" {
            //
            self.dismiss(animated: true, completion: {
                if (txnType == self.TXN_CFA) {
                    let cfa = CheckFundAvailability(estimatedTxnAmount: self.amount, withResponseCode: respCode, withTransactionCryptogram: t53, with: self)
                    do {
                        try ExceptionCatcher.catchException {
//                            self.showLoading()
                            cfa.invoke({ (result) in
                                print("result success = \(result)")
                                self.table0205 = result
                                UserDefaults.standard.set(self.table0205, forKey: "table0205")
//                                self.dismiss(animated: true, completion: {
                                    self.submitCFA(amount: self.amount, txnType: self.TXN_CFA)
//                                })
                            }, failure: { (error) in
//                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(errorCode: error, errorMessage: "")
                                    print("failed responseCode = " + error)
//                                })
                            })
                        }
                    } catch {
                        if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                            print(error.localizedDescription)
                        }
                        DispatchQueue.main.async() {
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                            })
                        }
                    }
                } else if (txnType == self.TXN_DEBIT) {
                    // will be implemented later
                    //                let debit = Debit(amount: "000000000100")
                    //                do {
                    //                    try ExceptionCatcher.catchException {
                    //                        self.showLoading()
                    //                        debit.invoke({ (result) in
                    //                            print("result success = \(result)")
                    //                            self.table0205 = result
                    //                            UserDefaults.standard.set(self.table0205, forKey: "table0205")
                    //                            self.submitCFA(amount: "100", txnType: self.TXN_DEBIT)
                    //                            self.hideLoading()
                    //                        }, failure: { (error) in
                    //                            self.showErrorMessage(errorCode: error, errorMessage: "")
                    //                            print("failed responseCode = " + error)
                    //                            self.hideLoading()
                    //                        })
                    //                    }
                    //                } catch {
                    //                    if error.localizedDescription == ServiceError.serviceNotInitializedException().reason {
                    //                        print(error.localizedDescription)
                    //                    }
                    //                }
                }
            })
        } else {
            self.dismiss(animated: true, completion: {
                if txnType == self.TXN_CFA {
                    if respCode == "00" {
                        self.showErrorMessage(errorCode: "00", errorMessage: "CFA Success")
                    } else {
                        self.showErrorMessage(errorCode: respCode, errorMessage: "CFA Failed")
                    }
                } else if (txnType == self.TXN_DEBIT) {
                    if respCode == "00" {
                        self.showErrorMessage(errorCode: "00", errorMessage: "Purchase Success")
                    } else {
                        self.showErrorMessage(errorCode: respCode, errorMessage: "Purchase Failed")
                    }
                }
            })
        }
    }
    
    @IBAction func doCFA(_ sender: Any) {
        guard let amt = txtAmount.text else {
            return
        }
        let c = (Double(amt)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        amount = b
        
       
        let cfa = CheckFundAvailability(estimatedTxnAmount: amount)
        do {
            try ExceptionCatcher.catchException {
                self.showLoading()
                cfa.invoke({ (result) in
                    print("result success = \(result)")
                    self.table0205 = result
                    UserDefaults.standard.set(self.table0205, forKey: "table0205")
                    self.dismiss(animated: true, completion: {
                        self.submitCFA(amount: self.amount, txnType: self.TXN_CFA)
                    })
                    
                }, failure: { (error) in
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: error, errorMessage: "")
                        print("failed responseCode = " + error)
                    })
                })
            }
        } catch {
            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                print(error.localizedDescription)
            }
            DispatchQueue.main.async() {
                self.dismiss(animated: true, completion: {
                    self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                })
            }
        }
    }
    
    @IBAction func doPurchase(_ sender: Any) {
        guard let amt = txtAmount.text else {
            return
        }
        let c = (Double(amt)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        amount = b
        let debit = Debit(amount: amount)
        do {
            try ExceptionCatcher.catchException {
                self.showLoading()
                debit.invoke({ (result) in
                    print("result success = \(result)")
                    self.table0205 = result
                    UserDefaults.standard.set(self.table0205, forKey: "table0205")
                    self.dismiss(animated: true, completion: {
                        self.submitCFA(amount: self.amount, txnType: self.TXN_DEBIT)
                    })
                }, failure: { (error) in
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: error, errorMessage: "Purchase failed")
                        print("failed responseCode = " + error)
                    })
                })
            }
        } catch {
            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                print(error.localizedDescription)
            }
            DispatchQueue.main.async() {
                self.dismiss(animated: true, completion: {
                    self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                })
            }
        }
    }
    
    
    
    func showErrorMessage(errorCode :String, errorMessage :String) {
        
        let alertController = UIAlertController(title: "Error : \(errorCode)", message: errorMessage, preferredStyle: .alert)
        
        if (errorCode == "9987 - 20035") {
            NofService.main().clearVOS()
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                exit(1)
            }))
        } else {
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        }
        present(alertController, animated: true, completion: nil)
        
    }
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    func hideLoading() {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func doTestCfaWithPin(_ sender: Any) {
        let cfa = CheckFundAvailability(estimatedTxnAmount: amount, withResponseCode: "u9", withTransactionCryptogram: "", with: self)
        do {
            try ExceptionCatcher.catchException {
                self.showLoading()
                cfa.invoke({ (result) in
                    print("result success = \(result)")
                    self.table0205 = result
                    UserDefaults.standard.set(self.table0205, forKey: "table0205")
                    self.dismiss(animated: true, completion: {
                        self.submitCFA(amount: "100", txnType: self.TXN_CFA)
                    })
                }, failure: { (error) in
                    self.dismiss(animated: true, completion: {
                        self.showErrorMessage(errorCode: error, errorMessage: "")
                        print("failed responseCode = " + error)
                    })
                })
            }
        } catch {
            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                print(error.localizedDescription)
            }
            DispatchQueue.main.async() {
                self.dismiss(animated: true, completion: {
                    self.showErrorMessage(errorCode: "", errorMessage: error.localizedDescription)
                })
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if let viewController = segue.destination as? AuthCodeTableViewController {
            viewController.amount = amount
            guard let muidStr = self.txtMuid.text else {
                return;
            }
            viewController.muid = muidStr
        }
        
    }
}

extension Request {
    public func debugLog() -> Self {
        #if DEBUG
        debugPrint(self)
//        print("REQUEST = %@", self)
        #endif
        return self
    }
}


