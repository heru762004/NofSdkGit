//
//  PayTelcoViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 2/7/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit
//import CurrencyTextField
//import Alamofire
//import CoreLocation

class PayTelcoViewController: UIViewController, UITableViewDataSource, UITableViewDelegate  {
    
    
    let MERCHANT_HOST_URL_CFA   = "/nof/cfa"
    let MERCHANT_HOST_URL_DIRECT_PURCHASE = "/nof/purchase"
    
    let arrayMenu = ["Payment", "Manage Payment", "Txn History"]
    let arrayMenu_beforeReg = ["Payment", "Manage Payment", "Reset App"]
    
    //600 - MOH
    //700 - MOM
    let arrayGovTechMid = ["11136127500", "11136127600", "11136127700", "11136127701"]
    let arrayGovTechTid = ["36127501", "36127601", "36127701", "36127702"]
    
    @IBOutlet weak var leadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var menuTableView: UITableView!
    
    @IBOutlet weak var bookingView: UIView!
    @IBOutlet weak var endTripView: UIView!
    
    @IBOutlet weak var tableEndTrip: UITableView!
    var menuShowing = false
    var arrayBooking: [Booking] = []
    var arrayTxnHistory: [TransactionHistory] = []
    
    let BOOKING_KEY = "NOF_BOOKING"
    let TXN_HISTORY_KEY = "NOF_TXN_HISTORY"
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    
    var selectedIdx: Int = -1
    @IBOutlet weak var bookAmount: CurrencyTextField!
    
    let TXN_CFA = 1
    let TXN_DEBIT = 2
    
    let IS_REGISTERED = "IS_REGISTERED"
    let MERCHANT_UID = "MERCHANT_UID"
    
    var muid = ""
    var chooseType = ""
    var selectedMid = ""
    var selectedTid = ""
    
    @IBOutlet weak var currentMuid: UILabel!
    @IBOutlet weak var currentMid: UILabel!
    @IBOutlet weak var bookingListTitle: UILabel!
    @IBOutlet weak var midChooser: UIPickerView!
    
    var table0205 = ""
    
    @IBOutlet weak var appNameLabel: UILabel!
    
    
//    var locationManager: CLLocationManager!
    
    override func viewDidLoad() {
        self.selectedMid = self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)
        self.selectedTid = self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN)
        super.viewDidLoad()
//        locationManager = CLLocationManager()
//        locationManager.requestAlwaysAuthorization()
        
        if let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String {
            if let minorAppVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String {
                appNameLabel.text = "Non Ride-Hailing App\nv \(appVersion).\(minorAppVersion)"
            }
        }
        menuTableView.delegate = self;
        menuTableView.dataSource = self;
        
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        self.midChooser.delegate = self
        self.midChooser.dataSource = self
        self.midChooser.reloadAllComponents()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        muid = self.getDataFromDB(keyName: MERCHANT_UID)
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
        if self.chooseType != "4" {
            self.midChooser.isHidden = true
        }
        self.currentMuid.text = "MUID : \(muid)"
        self.currentMid.text = "MID : \(self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN))"
        arrayBooking = self.getArrayFromDB(keyName: BOOKING_KEY)
        arrayTxnHistory = self.getArrayFromDB(keyName: TXN_HISTORY_KEY)
        print("ARRAY BOOKING = \(arrayBooking)")
        print("ARRAY TXN HISTORY = \(arrayTxnHistory)")
        print("IS REGISTERED = \(self.getDataFromDB(keyName: IS_REGISTERED))")
        tableEndTrip.reloadData()
        menuTableView.reloadData()
    }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[BookingComfortViewController] : \(#function)")
        self.view.endEditing(true)
    }
    
    @IBAction func doBooking(_ sender: Any) {
        print("dobook")
//        fatalError()
        let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
        if isReg.count == 0 || isReg == "0" {
            print("showError Message")
            self.showErrorMessage(responderCode: "", errorCode: "U002", errorMessage: "Payment has not been registered")
            return
        }
        
        guard let amount = bookAmount.text else {
            self.showErrorMessage(responderCode: "", errorCode: "U001", errorMessage: "Amount must be more than 0")
            return
        }
        
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        print(amountDouble)
        if Double(amountDouble)! <= 0.0 {
            self.showErrorMessage(responderCode: "", errorCode: "U001", errorMessage: "Amount must be more than 0")
            return
        }
        
        
        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        
//        let debit = Debit(mid: selectedMid, withAmount: b)
        let debit = Debit(amount: b)
        self.showLoading()
        DispatchQueue.global().async() {
            do {
                try ExceptionCatcher.catchException {
                    debit.invoke({ (result) in
                        print("result success = \(result)")
                        self.table0205 = result
                        UserDefaults.standard.set(self.table0205, forKey: "table0205")
                        self.submitCFA(amount: b, txnType: self.TXN_DEBIT)
                        
                    }, failure: { (error) in
                        DispatchQueue.main.async {
                            self.dismiss(animated: true, completion: {
                                OperationQueue.main.addOperation {
                                    self.showErrorMessage(responderCode: "", errorCode: error, errorMessage: "")
                                }
                            })
                        }
                        print("failed responseCode = " + error)
                    })
                }
            } catch {
                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    @IBAction func openSideMenu(_ sender: Any) {
        self.view.endEditing(true)
        if menuShowing {
            leadingConstraint.constant = -208
        } else {
            leadingConstraint.constant = 0
            UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseIn, animations: {
                self.view.layoutIfNeeded()
            }) { (completed) in
                // not used
            }
            
        }
        menuShowing = !menuShowing
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == menuTableView {
            let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
            if isReg.count == 0 || isReg == "0" {
                return arrayMenu_beforeReg.count
            } else {
                return arrayMenu.count
            }
        } else if tableView == tableEndTrip {
            let titleMenu = self.bookingListTitle.text
            if titleMenu == self.arrayMenu[1] {
                return arrayBooking.count
            } else if titleMenu == self.arrayMenu[2] {
                return arrayTxnHistory.count
            }
            
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tableEndTrip {
            return 90.0
        }
        return 45.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == menuTableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
            
            // Configure the cell...
            let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
            if isReg.count == 0 || isReg == "0" {
                let menuTitle = arrayMenu_beforeReg[indexPath.row]
                cell.textLabel?.text = menuTitle
            } else {
                let menuTitle = arrayMenu[indexPath.row]
                cell.textLabel?.text = menuTitle
            }
            
            return cell
        } else if tableView == tableEndTrip {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tableEndTripCell", for: indexPath)
            
            // Configure the cell...
            let titleMenu = self.bookingListTitle.text
            if titleMenu == self.arrayMenu[1] {
                let bookData = arrayBooking[indexPath.row]
                cell.textLabel?.text = "AMOUNT : \(bookData.bookingAmount)"
                cell.detailTextLabel?.numberOfLines = 4
                let txnTime = "\(bookData.bookingTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(bookData.bookingTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(bookData.bookingTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
                cell.detailTextLabel?.text = "AUTH CODE : \(bookData.bookingAuthCode)\nBOOKING TIME : \(bookData.bookingDate) \(txnTime)\nRRN : \(bookData.bookingRrn)\nTID : \(bookData.bookingTid)"
            } else if titleMenu == self.arrayMenu[2] {
                let bookData = arrayTxnHistory[indexPath.row]
                cell.textLabel?.text = "AMOUNT : \(bookData.bookingAmount)"
                cell.detailTextLabel?.numberOfLines = 4
                let txnTime = "\(bookData.bookingTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(bookData.bookingTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(bookData.bookingTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
                cell.detailTextLabel?.text = "AUTH CODE : \(bookData.bookingAuthCode)\nBOOKING TIME : \(bookData.bookingDate) \(txnTime)\nRRN : \(bookData.bookingRrn)\nTID : \(bookData.bookingTid)"
            }
            
            
            return cell
        }
        return tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if (tableView == menuTableView) {
            if indexPath.row == 0 {
                bookingView.isHidden = false
                endTripView.isHidden = true
            } else if indexPath.row == 1 {
                self.performSegue(withIdentifier: "managePayment", sender: self)
            } else if indexPath.row == 2 {
                let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
                if isReg.count == 0 || isReg == "0" {
                    self.storeDataToDB(keyValue: "", keyName: IS_CHOOSE_TYPE)
                    let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationType") as! UINavigationController
                    //                let navigationController = UINavigationController(rootViewController: exampleViewController)
                    UIApplication.shared.keyWindow?.rootViewController = exampleViewController
                    
                    UIApplication.shared.keyWindow?.makeKeyAndVisible()
                } else {
                    bookingView.isHidden = true
                    endTripView.isHidden = false
                    bookingListTitle.text = self.arrayMenu[indexPath.row]
                    arrayTxnHistory = self.getArrayFromDB(keyName: TXN_HISTORY_KEY)
                    tableEndTrip.reloadData()
                }
            }
            self.openSideMenu(self)
        } else if tableView == tableEndTrip {
            let titleMenu = self.bookingListTitle.text
            if titleMenu == self.arrayMenu[1] {
                selectedIdx = indexPath.row
                self.performSegue(withIdentifier: "endTripDetails", sender: self)
            } else if titleMenu == self.arrayMenu[2] {
                // txn history
                selectedIdx = indexPath.row
                self.performSegue(withIdentifier: "showTxnHistoryDetail", sender: self)
            }
        }
    }
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayBooking) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayBooking)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: BOOKING_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func saveArrayTxnHistoryToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayTxnHistory) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayTxnHistory)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: TXN_HISTORY_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func getArrayFromDB(keyName: String) -> [Booking] {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName)
        if let jsonData = strData?.data(using: String.Encoding.utf8) {
            let jsonDecoder = JSONDecoder()
            do {
                let arrayBooking = try jsonDecoder.decode([Booking].self, from: jsonData)
                return arrayBooking
            } catch let error {
                print(error)
                return [Booking]()
            }
        }
        return [Booking]()
    }
    
    func getArrayFromDB(keyName: String) -> [TransactionHistory] {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName)
        if let jsonData = strData?.data(using: String.Encoding.utf8) {
            let jsonDecoder = JSONDecoder()
            do {
                let arrayBooking = try jsonDecoder.decode([TransactionHistory].self, from: jsonData)
                return arrayBooking
            } catch let error {
                print(error)
                return [TransactionHistory]()
            }
        }
        return [TransactionHistory]()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewController = segue.destination as? ManageTelcoPaymentViewController {
            viewController.muid = muid
        } else if let viewController = segue.destination as? TxnHistoryTelcoDetailViewController {
            viewController.selectedIdx = selectedIdx
            viewController.arrayTxnHistory = arrayTxnHistory
            viewController.muid = muid
        }
    }
    
    
    func submitCFA(amount: String, txnType: Int) {
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        if chooseType == "0" || chooseType == "1" {
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        
        var url = "\(host)\(MERCHANT_HOST_URL_CFA)"
        if txnType == TXN_DEBIT {
            url = "\(host)\(MERCHANT_HOST_URL_DIRECT_PURCHASE)"
        }
        
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        self.storeDataToDB(keyValue: muuid!, keyName: "MUUID_DEBIT")
        self.storeDataToDB(keyValue: muid, keyName: "MUID_DEBIT")
        if let c = UserDefaults.standard.string(forKey: "table0205") {
            DispatchQueue.main.async{
                self.showLoading()
            }
            var table53 = ""
            var url = URLComponents(string: url)!
            
            url.queryItems = [
                URLQueryItem(name: "mid", value: self.selectedMid),
                URLQueryItem(name: "tid", value: self.selectedTid)
            ]
            let request = URLRequest(url: url.url!)
            let json: [String: Any] = ["t0205": c, "amt": amount, "muid": muid, "muuid": muuid!, "authCode": "000000"]
            
            NetworkHandler.requestServer(json: json, req: request) { (response, error) in
                DispatchQueue.main.async{
                    if let err = error {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                            })
                        }
                        return
                    }
                    if let jsonResponse = response {
                        guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                            return
                        }
                        
                        if strResponseCode != "00" && jsonResponse["responder"] == nil {
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Purchase Failed")
                            })
                            return
                        }
                        
                        if let strT53: String = jsonResponse["t5253"] as? String {
                            table53 = strT53
                        }
                        guard let strAuthCode: String = jsonResponse["authCode"] as? String else {
                            return
                        }
                        guard let strResponder: String = jsonResponse["responder"] as? String else {
                            return
                        }
                        
                        if strResponseCode == "00" {
                            guard let amount = self.bookAmount.text else {
                                return
                            }
                            let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
                            if Double(amountDouble)! <= 0.0 {
                                return
                            }
                            let currentDate = Date()
                            let format = DateFormatter()
                            format.dateFormat = "yyyy"
                            let formattedDate = format.string(from: currentDate)
                            guard let mDate: String = jsonResponse["transactionDate"] as? String else {
                                return
                            }
                            
                            let book = Booking()
                            book.bookingAmount = amount
                            book.bookingAuthCode = strAuthCode
                            book.bookingDate = "\(formattedDate)-\(mDate.myOwnSubstring(startIndex: 0, endIndex: 2))-\(mDate.myOwnSubstring(startIndex: 2, endIndex: 4))"
                            guard let txnTime: String = jsonResponse["transactionTime"] as? String else {
                                return
                            }
                            book.bookingTime = txnTime
                            guard let txnTid: String = jsonResponse["tid"] as? String else {
                                return
                            }
                            book.bookingTid = txnTid.replacingOccurrences(of: " ", with: "")
                            
                            guard let txnMid: String = jsonResponse["mid"] as? String else {
                                return
                            }
                            book.bookingMid = txnMid.replacingOccurrences(of: " ", with: "")
                            guard let txnRrn: String = jsonResponse["rrn"] as? String else {
                                return
                            }
                            book.bookingRrn = txnRrn.replacingOccurrences(of: " ", with: "")
                            let txnHistory = TransactionHistory(book: book)
                            self.arrayTxnHistory.append(txnHistory)
                            self.saveArrayTxnHistoryToDB(keyName: self.TXN_HISTORY_KEY)
                        }
                        if table53.count == 183 {
                            table53 = table53.myOwnSubstring(startIndex: 78, endIndex: table53.count)
                        }
                        print("Table 53 count = \(table53.count)")
                        print("Table 53 = \(table53)")
                        self.handleResponsePurchase(respCode: strResponseCode, t53: table53, txnType: txnType, responderCode:  strResponder)
                    }
                }
                    
            }
        }
        
    }
    
    func showErrorMessage(responderCode: String, errorCode :String, errorMessage :String) {
        if errorCode == "00" {
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Status : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Status : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                //                self.storeDataToDB(keyValue: "0", keyName: self.IS_REGISTERED)
                let titleMenu = self.bookingListTitle.text
                if titleMenu == "Book a Cab" {
                } else {
                    self.navigationController?.dismiss(animated: true, completion: nil)
                }
            }))
            present(alertController, animated: true, completion: nil)
            
        } else if errorCode == "U002" {
            let alertController = UIAlertController(title: "Error : \(errorCode)", message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                self.performSegue(withIdentifier: "managePayment", sender: self)
                //                self.navigationController?.dismiss(animated: true, completion: nil)
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9982")  {
                errMsg = "\(errMsg) - Invalid transaction amount"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Error : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Error : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errMsg, preferredStyle: .alert)
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    
    func handleResponsePurchase(respCode: String, t53: String, txnType: Int, responderCode: String) {
        guard let amount = bookAmount.text else {
            return
        }
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            return
        }
        //        let currentDate = Date()
        //        let format = DateFormatter()
        //        format.dateFormat = "yyyy-MM-dd HH:mm:ss"
        //        let formattedDate = format.string(from: currentDate)
        //        let authCode = "129012"
        //        let book = Booking()
        //        book.bookingAmount = amount
        //        book.bookingAuthCode = authCode
        //        book.bookingTime = formattedDate
        //        arrayBooking.append(book)
        //        self.saveArrayToDB(keyName: BOOKING_KEY)
        
        
        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        if respCode == "U9" || respCode == "55" {
            //
            self.dismiss(animated: true, completion: {
                if (txnType == self.TXN_CFA) {
                    
                    let cfa = CheckFundAvailability(estimatedTxnAmount: b, withResponseCode: respCode, withTransactionCryptogram: t53, with: self)
                    DispatchQueue.global().async() {
                        do {
                            try ExceptionCatcher.catchException {
                                //                            self.showLoading()
                                cfa.invoke({ (result) in
                                    print("result success = \(result)")
                                    self.table0205 = result
                                    UserDefaults.standard.set(self.table0205, forKey: "table0205")
                                    //                                self.dismiss(animated: true, completion: {
                                    DispatchQueue.main.async() {
                                        self.submitCFA(amount: b, txnType: self.TXN_CFA)
                                    }
                                    //                                })
                                }, failure: { (error) in
                                    DispatchQueue.main.async() {
                                        self.showErrorMessage(responderCode: "", errorCode: error, errorMessage: "")
                                        print("failed responseCode = " + error)
                                    }
                                    //                                })
                                })
                            }
                        } catch {
                            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                                print(error.localizedDescription)
                            }
                            DispatchQueue.main.async() {
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(responderCode: "", errorCode: "", errorMessage: error.localizedDescription)
                                })
                            }
                        }
                    }
                } else if (txnType == self.TXN_DEBIT) {
                    let debit = Debit(amount: b, withResponseCode: respCode, withTransactionCryptogram: t53, with: self)
//                    let debit = Debit(mid: self.selectedMid, withAmount: b, withResponseCode: respCode, withTransactionCryptogram: t53, with: self)
                    DispatchQueue.global().async() {
                        do {
                            try ExceptionCatcher.catchException {
                                //                            self.showLoading()
                                debit.invoke({ (result) in
                                    print("result success = \(result)")
                                    self.table0205 = result
                                    UserDefaults.standard.set(self.table0205, forKey: "table0205")
                                    //                                self.dismiss(animated: true, completion: {
                                    DispatchQueue.main.async() {
                                        self.submitCFA(amount: b, txnType: self.TXN_DEBIT)
                                    }
                                    //                                })
                                }, failure: { (error) in
                                    DispatchQueue.main.async() {
                                        self.showErrorMessage(responderCode: "", errorCode: error, errorMessage: "")
                                        print("failed responseCode = " + error)
                                    }
                                    //                                })
                                })
                            }
                        } catch {
                            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                                print(error.localizedDescription)
                            }
                            DispatchQueue.main.async() {
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(responderCode: "", errorCode: "", errorMessage: error.localizedDescription)
                                })
                            }
                        }
                    }
                }
            })
        } else if respCode == "75" {
            self.dismiss(animated: true, completion: {
                self.showErrorMessage(responderCode: responderCode, errorCode: respCode, errorMessage: "Pin Retry Limit Exceeded")
            })
        } else {
            print("ERROR = \(respCode)")
            self.dismiss(animated: true, completion: {
                if txnType == self.TXN_CFA {
                    if respCode == "00" {
                        self.showErrorMessage(responderCode: responderCode, errorCode: "00", errorMessage: "CFA Success")
                    } else {
                        self.showErrorMessage(responderCode: responderCode, errorCode: respCode, errorMessage: "CFA Failed")
                    }
                } else if (txnType == self.TXN_DEBIT) {
                    if respCode == "00" {
                        self.showErrorMessage(responderCode: responderCode, errorCode: "00", errorMessage: "Purchase Success")
                    } else {
                        self.showErrorMessage(responderCode: responderCode, errorCode: respCode, errorMessage: "Purchase Failed")
                    }
                }
            })
        }
    }
    
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    
    
    func storeDataToDB(keyValue: String, keyName: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PayTelcoViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrayGovTechMid.count
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let attributeString = NSAttributedString(string: arrayGovTechMid[row], attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
        return attributeString
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.currentMid.text = "MID : \(arrayGovTechMid[row])"
        self.selectedMid = arrayGovTechMid[row]
        self.selectedTid = arrayGovTechTid[row]
//        self.storeDataToDB(keyValue: selectedMid, keyName: TypeMainMenuViewController.MID_CHOOSEN)
//        self.storeDataToDB(keyValue: selectedTid, keyName: TypeMainMenuViewController.TID_CHOOSEN)
    }
    
}
