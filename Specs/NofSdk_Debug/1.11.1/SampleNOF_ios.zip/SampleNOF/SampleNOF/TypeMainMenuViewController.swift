//
//  TypeMainMenuViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 1/7/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit

class TypeMainMenuViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    #if SIT
//    static let mid_rha = "11181300100"
//    static let tid_rha = "81300100"
//    static let mid_nrha = "11151300100"
//    static let tid_nrha = "51300100"
    static let mid_rha = "11138032900"
    static let tid_rha = "38032900"
    static let mid_nrha = "11138032800"
    static let tid_nrha = "38032800"
    static let mid_rhb = "11136127400"
    static let tid_rhb = "36127401"
    static let mid_nrhb = "11136127300"
    static let tid_nrhb = "36127301"
    static let mid_govtech = "11136127500"
    static let tid_govtech = "36127501"
    static let mid_dbs = ""
    static let tid_dbs = ""
    static let mid_nets = ""
    static let tid_nets = ""
    #elseif UAT
    static let mid_rha = "11138032900"
    static let tid_rha = "38032900"
    static let mid_nrha = "11138032800"
    static let tid_nrha = "38032800"
    static let mid_rhb = "11136127400"
    static let tid_rhb = "36127401"
    static let mid_nrhb = "11136127300"
    static let tid_nrhb = "36127301"
    static let mid_govtech = "11138032901"
    static let tid_govtech = "38032901"
    static let mid_dbs = ""
    static let tid_dbs = ""
    static let mid_nets = ""
    static let tid_nets = ""
    #elseif PROD
    static let mid_rha = "11138032800"
    static let tid_rha = "38032800"
    static let mid_nrha = "11138032900"
    static let tid_nrha = "38032900"
    static let mid_rhb = "11136127400"
    static let tid_rhb = "36127401"
    static let mid_nrhb = "11136127300"
    static let tid_nrhb = "36127301"
    static let mid_govtech = "11138032901"
    static let tid_govtech = "38032901"
    #endif
    
    
    
    var menu :[Dictionary<String, String>] = [Dictionary<String, String>]()
    @IBOutlet weak var menuTable: UITableView!
    
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    static let MID_CHOOSEN = "MID_CHOOSEN"
    static let TID_CHOOSEN = "TID_CHOOSEN"
    
    override func viewWillAppear(_ animated: Bool) {
        let isChoosed = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
        print(isChoosed)
        if (isChoosed == "") {
            
        } else {
            if (isChoosed == "0") {
                // go to ride hailing
                self.performSegue(withIdentifier: "showRideHailing", sender: nil)
                self.dismiss(animated: false, completion: nil)
            } else if (isChoosed == "1") {
                // go to nets telco
                self.performSegue(withIdentifier: "showTelco", sender: nil)
                self.dismiss(animated: false, completion: nil)
            }
        }
    }
    
    override func viewDidLoad() {
        let ENV = Utils.infoForKey("ENV")!
        menu = Utils.configForKey(env: ENV)!
        menuTable.delegate = self
        menuTable.dataSource = self
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == menuTable {
            return menu.count
        }
        return 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == menuTable {
            let cell = tableView.dequeueReusableCell(withIdentifier: "typeTableViewCell", for: indexPath)
            
            // Configure the cell...
            cell.textLabel?.text = menu[indexPath.row]["MerchantName"]
            cell.detailTextLabel?.text = menu[indexPath.row]["MID"]
            return cell
        }
        return tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if tableView == menuTable {
            print("storeDataDB = \(indexPath.row)")
            self.storeDataToDB(keyValue: menu[indexPath.row]["MID"]!, keyName: TypeMainMenuViewController.MID_CHOOSEN)
            self.storeDataToDB(keyValue: menu[indexPath.row]["TID"]!, keyName: TypeMainMenuViewController.TID_CHOOSEN)
            guard let type = menu[indexPath.row]["Type"] else {
                return
            }
            self.storeDataToDB(keyValue: type, keyName: IS_CHOOSE_TYPE)
            if type == "CFA" {
                let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationMain") as! UINavigationController
                //                let navigationController = UINavigationController(rootViewController: exampleViewController)
                UIApplication.shared.keyWindow?.rootViewController = exampleViewController
                
                UIApplication.shared.keyWindow?.makeKeyAndVisible()
//                self.performSegue(withIdentifier: "showRideHailing", sender: nil)
            } else if type == "DEBIT" {
                let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationTelco") as! UINavigationController
                //                let navigationController = UINavigationController(rootViewController: exampleViewController)
                UIApplication.shared.keyWindow?.rootViewController = exampleViewController
                
                UIApplication.shared.keyWindow?.makeKeyAndVisible()
            }
        }
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }
    
    func storeDataToDB(keyValue: String, keyName: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
