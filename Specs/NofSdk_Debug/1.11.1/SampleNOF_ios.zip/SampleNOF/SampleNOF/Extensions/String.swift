//
//  String.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 25/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import Foundation

extension String {
    func myOwnSubstring(startIndex:Int, endIndex:Int) -> String {
        var result:String = ""
        if endIndex > self.count {
            return result
        }
        
        for x in startIndex  ..< endIndex {
            // logger.debug("index : \(x) \(startIndex)-\(endIndex)")
            let characterIndex = self.index(self.startIndex, offsetBy:x)
            result.append(self[characterIndex])
        }
        return result
    }
}
