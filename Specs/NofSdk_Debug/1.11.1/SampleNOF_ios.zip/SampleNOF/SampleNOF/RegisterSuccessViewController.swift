//
//  RegisterSuccessViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 22/7/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit

protocol RegisterSuccessViewDelegate {
    func dismissView()
}

class RegisterSuccessViewController: UIViewController {

    @IBOutlet weak var imageTick: UIImageView!
    @IBOutlet weak var textSuccess: UILabel!
    
    var typeRegister: Int = 0
    var delegate : RegisterSuccessViewDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        var animationArray: [UIImage] = []
        for index in 1...9 {
            let imageName = "s000\(index)"
            animationArray.append(UIImage(named: imageName)!)
        }
        
        for index in 10...32 {
            let imageName = "s00\(index)"
            animationArray.append(UIImage(named: imageName)!)
        }
        imageTick.animationImages = animationArray
        imageTick.animationDuration = 2.6
        
        imageTick.startAnimating()
        
        if (typeRegister == 1) {
            textSuccess.text = "You can now use NETS Click to pay for your purchase."
        }
        
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    func setDelegate(delegate: RegisterSuccessViewDelegate) {
        self.delegate = delegate
    }
    
    func setTypeText(type: Int) {
        typeRegister = type
        
    }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[RegisterSuccessViewController] : \(#function)")
        self.view.endEditing(true)
        if (self.delegate != nil) {
            self.delegate.dismissView()
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
