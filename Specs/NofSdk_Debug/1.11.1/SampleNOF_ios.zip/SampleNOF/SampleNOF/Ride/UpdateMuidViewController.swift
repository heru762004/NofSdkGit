//
//  UpdateMuidViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 4/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit

class UpdateMuidViewController: UIViewController {
    
    var muid = ""
    let MERCHANT_UID = "MERCHANT_UID"
    let BOOKING_KEY = "NOF_BOOKING"
    let MERCHANT_HOST_URL       = "/nof/gmt"
    let IS_REGISTERED = "IS_REGISTERED"
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    
    var arrayBooking: [Booking] = []
    
    var table0102 = ""
    var chooseType = ""
    
    @IBOutlet weak var newMuidTxt: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newMuidTxt.text = muid
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[UpdateMuidViewController] : \(#function)")
        self.view.endEditing(true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func doUpdateMuid(_ sender: Any) {
        if let newMuid = newMuidTxt.text {
            self.view.endEditing(true)
            self.doUpdateMuid(newMuid: newMuid)
        }
    }
    
    func doUpdateMuid(newMuid: String) {
        print("do Update MUID")
//        let updateMuid = UpdateMuid(muid: newMuid, andWith: self, withNavigationBarColor: UIColor(displayP3Red: 0, green: (128/255), blue: (247.0/255.0), alpha: 1.0), withTitleBarColor: UIColor.white)
////        let updateMuid = UpdateMuid(muid: newMuid, andWith: self)
//        DispatchQueue.global().async() {
//            do {
//                try ExceptionCatcher.catchException {
//                    updateMuid.invoke({ (result) in
//                        DispatchQueue.main.async() {
//                            print("result success = \(result)")
//                            self.table0102 = result;
//                            UserDefaults.standard.set(self.table0102, forKey: "table0102")
//                            self.doGetMerchantToken(newMuid: newMuid)
////                            self.showErrorMessage(errorCode: "00", errorMessage: "update muid success")
//                        }
//                    }, failure: { (error) in
//                        DispatchQueue.main.async() {
//                            self.showErrorMessage(errorCode: error, errorMessage: "update muid failed")
//                            print("failed responseCode = " + error)
//                        }
//                    })
//                }
//            } catch {
//                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
//                    print(error.localizedDescription)
//                }
//                DispatchQueue.main.async() {
//                    self.dismiss(animated: true, completion: nil)
//                }
//            }
//        }
    }
    
    func showErrorMessage(errorCode :String, errorMessage :String) {
        if errorCode == "00" {
            let alertController = UIAlertController(title: "Status : \(errorCode)", message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
//                self.performSegue(withIdentifier: "registerSuccess", sender: self)
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            let alertController = UIAlertController(title: "Error : \(errorCode)", message: errMsg, preferredStyle: .alert)
            
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }
    
    func storeDataToDB(keyValue: String, keyName: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayBooking) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayBooking)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: BOOKING_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    func doGetMerchantToken(newMuid :String) {
        if let c = UserDefaults.standard.string(forKey: "table0102") {
            self.showLoading()
            let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
            
            DispatchQueue.global().async() {
//                let manager = Alamofire.SessionManager.default
                
                var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
                if self.chooseType == "0" || self.chooseType == "1" {
                    host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
                }
                let url = URLComponents(string: "\(host)\(self.MERCHANT_HOST_URL)")!
                let request = URLRequest(url: url.url!)
                
                let json: [String: Any] =  ["t0102": c, "muid": newMuid, "muuid": muuid!]
                NetworkHandler.requestServer(json: json, req: request) { (response, error) in
                    DispatchQueue.main.async{
                        if let err = error {
                            DispatchQueue.main.async{
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                                })
                            }
                            return
                        }
                        if let jsonResponse = response {
                            guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                                return
                            }
                            var message = ""
                            if strResponseCode == "00" {
                                message = "Update Muid Success"
                                self.storeDataToDB(keyValue: newMuid, keyName: self.MERCHANT_UID)
                                self.saveArrayToDB(keyName: self.BOOKING_KEY)
                                let mUID = self.getDataFromDB(keyName: self.MERCHANT_UID)
                                print("new MUID = \(mUID)")
                                DispatchQueue.main.async{
                                    self.dismiss(animated: true, completion: {
                                        OperationQueue.main.addOperation {
                                            self.showErrorMessage(errorCode: strResponseCode, errorMessage: message)
                                        }
                                    })
                                    
                                }
                            } else {
                                message = "Get Merchant Token Failure"
                                DispatchQueue.main.async{
                                    self.dismiss(animated: true, completion: {
                                        OperationQueue.main.addOperation {
                                            self.showErrorMessage(errorCode: strResponseCode, errorMessage: message)
                                        }
                                    })
                                    
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
