//
//  EndTripDetailViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 3/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit
//import CurrencyTextField

class EndTripDetailViewController: UIViewController {

    let MERCHANT_HOST_URL_CFA_PURCHASE = "/nof/cfapurchase"
    let MERCHANT_HOST_URL_CFA_CANCEL = "/nof/cfacancel"
    let MERCHANT_HOST_URL_PURCHASE_REVERSAL = "/nof/purchasereversal"
    
    var selectedIdx: Int = -1
    var arrayBooking: [Booking] = []
    var arrayTxnHistory: [TransactionHistory] = []
    
    let BOOKING_KEY = "NOF_BOOKING"
    let TXN_HISTORY_KEY = "NOF_TXN_HISTORY"
    let MERCHANT_UID = "MERCHANT_UID"
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    
    var TxnDate = ""
    var TxnTime = ""
    var AuthCode = ""
    var RRN = ""
    var TID = ""
    var Amount = ""
    
    var t_TxnDateTime = ""
    var t_AuthCode = ""
    var t_RRN = ""
    var t_TID = ""
    var t_Amount = ""
    
    var muid = ""
    var chooseType = ""
    @IBOutlet weak var bookingDateTimeTitle: UILabel!
    @IBOutlet weak var bookingAuthCodeTitle: UILabel!
    @IBOutlet weak var bookingRrnTitle: UILabel!
    @IBOutlet weak var bookingTidTitle: UILabel!
    @IBOutlet weak var bookingAmountText: CurrencyTextField!
    
    override func viewWillAppear(_ animated: Bool) {
        muid = self.getDataFromDB(keyName: MERCHANT_UID)
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arrayTxnHistory = self.getArrayFromDB(keyName: TXN_HISTORY_KEY)
        let bookData = arrayBooking[selectedIdx]
        let txnTime = "\(bookData.bookingTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(bookData.bookingTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(bookData.bookingTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
        
        TxnTime = txnTime
        TxnDate = bookData.bookingDate
        AuthCode = bookData.bookingAuthCode
        RRN = bookData.bookingRrn
        TID = bookData.bookingTid
        Amount = bookData.bookingAmount
        
        t_TxnDateTime = bookingDateTimeTitle.text!
        t_AuthCode = bookingAuthCodeTitle.text!
        t_RRN = bookingRrnTitle.text!
        t_TID = bookingTidTitle.text!
        t_Amount = bookingAmountText.text!
        
        loadData()
        
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        
//        bookingDateTimeTitle.isUserInteractionEnabled = true
//        bookingDateTimeTitle.tag = 1001
//        bookingDateTimeTitle.addGestureRecognizer(setGesture())
        
        bookingAuthCodeTitle.isUserInteractionEnabled = true
        bookingAuthCodeTitle.tag = 1002
        bookingAuthCodeTitle.addGestureRecognizer(setGesture())
        
        bookingRrnTitle.isUserInteractionEnabled = true
        bookingRrnTitle.tag = 1003
        bookingRrnTitle.addGestureRecognizer(setGesture())
        
        bookingTidTitle.isUserInteractionEnabled = true
        bookingTidTitle.tag = 1004
        bookingTidTitle.addGestureRecognizer(setGesture())
        // Do any additional setup after loading the view.
    }
    
    func setGesture() -> UITapGestureRecognizer {
         let myRecognizer = UITapGestureRecognizer(target: self, action: #selector(editFields(_sender:)))
         return myRecognizer
    }
    
    func loadData() {
           bookingDateTimeTitle.text = "\(t_TxnDateTime) \(TxnDate) \(TxnTime)"
           bookingAuthCodeTitle.text = "\(t_AuthCode) \(AuthCode)"
           bookingRrnTitle.text = "\(t_RRN) \(RRN)"
           bookingTidTitle.text = "\(t_TID) \(TID)"
           bookingAmountText.text = Amount
       }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[EndTripDetailViewController] : \(#function)")
        self.view.endEditing(true)
    }
    
    @IBAction func doEndTrip(_ sender: Any) {
//        arrayBooking.remove(at: selectedIdx)
//        self.saveArrayToDB(keyName: BOOKING_KEY)
//        self.navigationController?.popViewController(animated: true)
        self.doEndTrip(authCode: arrayBooking[selectedIdx].bookingAuthCode)
    }
    
    @IBAction func doCancelTrip(_ sender: Any) {
        self.doCancelTrip(authCode: arrayBooking[selectedIdx].bookingAuthCode)
    }
    
    func doEndTrip(authCode: String) {
        guard let amount = bookingAmountText.text else {
            return
        }
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            self.showErrorMessage(responderCode: "", errorCode: "U001", errorMessage: "Amount must be more than 0")
            return
        }
        
        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        self.showLoading()
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        if self.chooseType == "0" || self.chooseType == "1" {
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        var url = URLComponents(string: "\(host)\(MERCHANT_HOST_URL_CFA_PURCHASE)")!
        
        url.queryItems = [
            URLQueryItem(name: "mid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)),
            URLQueryItem(name: "tid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN))
        ]
        
        let request = URLRequest(url: url.url!)
        let json: [String: Any] = ["amt": b, "muid": muid, "muuid": muuid!, "authCode": authCode]
        
        NetworkHandler.requestServer(json: json, req: request) { (response, error) in
            DispatchQueue.main.async{
                if let err = error {
                    DispatchQueue.main.async{
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode: "", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                        })
                    }
                    return
                }
                if let jsonResponse = response {
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        return
                    }
                    
                    if strResponseCode != "00" && jsonResponse["responder"] == nil {
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "End Trip Failed")
                        })
                        return
                    }
                    
                    guard let strResponder: String = jsonResponse["responder"] as? String else {
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
//                        let book = self.arrayBooking[self.selectedIdx]
//                        book.bookingAmount = amount
                        guard let amount = self.bookingAmountText.text else {
                            return
                        }
                        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
                        if Double(amountDouble)! <= 0.0 {
                            return
                        }
                        let currentDate = Date()
                        let format = DateFormatter()
                        format.dateFormat = "yyyy"
                        let formattedDate = format.string(from: currentDate)
                        guard let mDate: String = jsonResponse["transactionDate"] as? String else {
                            return
                        }

                        let book = Booking()
                        book.bookingAmount = amount
                        book.bookingAuthCode = self.AuthCode
                        if let authCode: String = jsonResponse["authCode"] as? String {
                            book.bookingAuthCode = authCode
                        }
                        book.bookingDate = "\(formattedDate)-\(mDate.myOwnSubstring(startIndex: 0, endIndex: 2))-\(mDate.myOwnSubstring(startIndex: 2, endIndex: 4))"
                        guard let txnTime: String = jsonResponse["transactionTime"] as? String else {
                            return
                        }
                        book.bookingTime = txnTime
                        guard let txnTid: String = jsonResponse["tid"] as? String else {
                            return
                        }
                        book.bookingTid = txnTid.replacingOccurrences(of: " ", with: "")

                        guard let txnMid: String = jsonResponse["mid"] as? String else {
                            return
                        }
                        book.bookingMid = txnMid.replacingOccurrences(of: " ", with: "")
                        guard let txnRrn: String = jsonResponse["rrn"] as? String else {
                            return
                        }
                        book.bookingRrn = txnRrn.replacingOccurrences(of: " ", with: "")
                        let txnHistory = TransactionHistory(book: book)
                        txnHistory.purchased = true
                        self.arrayTxnHistory.append(txnHistory)
                        self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
                        self.arrayBooking.remove(at: self.selectedIdx)
                        self.saveArrayToDB(keyName: self.BOOKING_KEY)
                        
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: strResponder, errorCode: strResponseCode, errorMessage: "End Trip Success")
                            })
                        }
                    } else {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: strResponder, errorCode: strResponseCode, errorMessage: "End Trip failed")
                            })
                        }
                    }
                }
            }
        }
        
    }
    
    @IBAction func doReversal(_ sender: Any) {
        guard let amount = bookingAmountText.text else {
            return
        }
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            return
        }
        
        self.showLoading()
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        if self.chooseType == "0" || self.chooseType == "1" {
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        var url = URLComponents(string: "\(host)\(MERCHANT_HOST_URL_PURCHASE_REVERSAL)")!
        
        url.queryItems = [
            URLQueryItem(name: "mid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)),
            URLQueryItem(name: "tid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN))
        ]
        
        let request = URLRequest(url: url.url!)
       
        let json: [String: Any] = ["muid": muid, "muuid": muuid!, "authCode": arrayBooking[selectedIdx].bookingAuthCode]
        NetworkHandler.requestServer(json: json, req: request) { (response, error) in
            DispatchQueue.main.async{
                if let err = error {
                    DispatchQueue.main.async{
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode: "", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                        })
                    }
                    return
                }
                if let jsonResponse = response {
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
                        let book = self.arrayBooking[self.selectedIdx]
                        book.bookingAmount = amount
                        let txnHistory = TransactionHistory(book: book)
                        self.arrayTxnHistory.append(txnHistory)
                        self.arrayBooking.remove(at: self.selectedIdx)
                        self.saveArrayToDB(keyName: self.BOOKING_KEY)
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Reversal Purchase Success")
                            })
                        }
                    } else {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Reversal Purchase failed")
                            })
                        }
                    }
                }
            }
        }
    }
    
    func doCancelTrip(authCode: String) {
        guard let amount = bookingAmountText.text else {
            return
        }
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            return
        }
        
        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        self.showLoading()
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        if self.chooseType == "0" || self.chooseType == "1" {
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        var url = URLComponents(string: "\(host)\(MERCHANT_HOST_URL_CFA_CANCEL)")!
        
        url.queryItems = [
            URLQueryItem(name: "mid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)),
            URLQueryItem(name: "tid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN))
        ]
        
        let request = URLRequest(url: url.url!)
        
        let json: [String: Any] = ["amt": b, "muid": muid, "muuid": muuid!, "authCode": authCode]
        NetworkHandler.requestServer(json: json, req: request) { (response, error) in
            DispatchQueue.main.async{
                if let err = error {
                    DispatchQueue.main.async{
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode: "", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                        })
                    }
                    return
                }
                if let jsonResponse = response {
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
                        self.arrayBooking.remove(at: self.selectedIdx)
                        self.saveArrayToDB(keyName: self.BOOKING_KEY)
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Cancel Trip Success")
                            })
                        }
                    } else {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Cancel Trip failed")
                            })
                        }
                    }
                }
            }
        }
    }
    
    func showErrorMessage(responderCode: String, errorCode :String, errorMessage :String) {
        if errorCode == "00" {
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Status : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Status : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                
                self.navigationController?.popViewController(animated: true)
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Error : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Error : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errMsg, preferredStyle: .alert)
            
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayBooking) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayBooking)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: keyName)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func saveTxnHistoryArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayTxnHistory) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayTxnHistory)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: keyName)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }

    func getArrayFromDB(keyName: String) -> [TransactionHistory] {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName)
        if let jsonData = strData?.data(using: String.Encoding.utf8) {
            let jsonDecoder = JSONDecoder()
            do {
                let arrayBooking = try jsonDecoder.decode([TransactionHistory].self, from: jsonData)
                return arrayBooking
            } catch let error {
                print(error)
                return [TransactionHistory]()
            }
        }
        return [TransactionHistory]()
    }
    
    @objc func editFields(_sender: UITapGestureRecognizer) {
        print("sender = \(_sender)")
        if _sender.view?.tag == 1001 {
            let title = t_TxnDateTime
            let defValue = "\(TxnDate) \(TxnTime)"
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1002 {
            let title = t_AuthCode
            let defValue = AuthCode
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1003 {
            let title = t_RRN
            let defValue = RRN
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1004 {
            let title = t_TID
            let defValue = TID
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1005 {
            let title = t_Amount
            let defValue = Amount
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
    }
    
    func showInput(title: String, defaultVal: String, tag: Int) {
        //1. Create the alert controller.
        let alert = UIAlertController(title: "", message: title, preferredStyle: .alert)


        //2. Add the text field. You can configure it however you need.
        alert.addTextField { (textField) in
            textField.text = defaultVal
        }

        // 3. Grab the value from the text field, and print it when the user clicks OK.
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { [weak alert] (_) in
        }))

        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0]
            if tag == 1001 {
                if let str = textField?.text {
                    let dt = str.split(separator: " ")
                    if (dt.count > 1) {
                        self.TxnDate = "\(dt[0])"
                        self.TxnTime = "\(dt[1])"
                    }
                    self.loadData()
                }
            }
            if tag == 1002 {
                if let str = textField?.text {
                    self.AuthCode = str
                    self.loadData()
                }
            }
            
            if tag == 1003 {
                if let str = textField?.text {
                    self.RRN = str
                    self.loadData()
                }
            }
            
            if tag == 1004 {
                if let str = textField?.text {
                    self.TID = str
                    self.loadData()
                }
            }
            
            if tag == 1005 {
                if let str = textField?.text {
                    self.Amount = str
                    self.loadData()
                }
            }
            print(textField)
        }))
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)

    }
    
    func convertAmountToStr(amount: String) -> String {
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            return "000000000000"
        }
        
        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        return b
    }
    
    func convertTxnDateToStr(txnDate: String) -> String {
        let str = txnDate.split(separator: "-")
        print(str)
        let b = "\(str[1])\(str[2])"
        return b
    }
    
    func convertTxnTimeToStr(txnTime: String) -> String {
        let str = txnTime.split(separator: ":")
        let b = "\(str[0])\(str[1])\(str[2])"
        return b
    }
    
}
