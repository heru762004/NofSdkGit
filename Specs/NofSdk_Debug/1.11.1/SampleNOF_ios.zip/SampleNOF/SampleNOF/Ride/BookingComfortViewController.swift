//
//  BookingComfortViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 1/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit
//import CurrencyTextField
//import CoreLocation

class BookingComfortViewController: UIViewController, UITableViewDataSource, UITableViewDelegate  {
    let MERCHANT_HOST_URL_CFA   = "/nof/cfa"
    let MERCHANT_HOST_URL_DIRECT_PURCHASE = "/nof/purchase"
    
    let arrayMenu = ["Book", "Booking List", "Manage Payment", "Txn History"]
    let arrayMenu_beforeReg = ["Book", "Booking List", "Manage Payment", "Reset App"]
    
    @IBOutlet weak var leadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var menuTableView: UITableView!
    
    @IBOutlet weak var bookingView: UIView!
    @IBOutlet weak var endTripView: UIView!
    
    @IBOutlet weak var tableEndTrip: UITableView!
    var menuShowing = false
    var arrayBooking: [Booking] = []
    var arrayTxnHistory: [TransactionHistory] = []
    
    let BOOKING_KEY = "NOF_BOOKING"
    let TXN_HISTORY_KEY = "NOF_TXN_HISTORY"
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    
    var selectedIdx: Int = -1
    @IBOutlet weak var bookAmount: CurrencyTextField!
    
    let TXN_CFA = 1
    let TXN_DEBIT = 2
    
    let IS_REGISTERED = "IS_REGISTERED"
    let MERCHANT_UID = "MERCHANT_UID"
    
    var muid = ""
    var chooseType = ""
    
    @IBOutlet weak var currentMuid: UILabel!
    @IBOutlet weak var currentMid: UILabel!
    @IBOutlet weak var bookingListTitle: UILabel!
    
    var table0205 = ""
    
    @IBOutlet weak var appNameLabel: UILabel!
//    var locationManager: CLLocationManager!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
//        locationManager = CLLocationManager()
//        locationManager.requestAlwaysAuthorization()
        
        if let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String {
            if let minorAppVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String {
                appNameLabel.text = "Book Taxi App\nv \(appVersion).\(minorAppVersion)"
            }
        }
        menuTableView.delegate = self;
        menuTableView.dataSource = self;
//        arrayBooking = self.getArrayFromDB(keyName: BOOKING_KEY)
//        print("ARRAY BOOKING = \(arrayBooking)")
//        tableEndTrip.reloadData()
        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        muid = self.getDataFromDB(keyName: MERCHANT_UID)
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
        self.currentMuid.text = "MUID : \(muid)"
        self.currentMid.text = "MID : \(self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN))"
        arrayBooking = self.getArrayFromDB(keyName: BOOKING_KEY)
        arrayTxnHistory = self.getArrayFromDB(keyName: TXN_HISTORY_KEY)
        print("ARRAY BOOKING = \(arrayBooking)")
        print("IS REGISTERED = \(self.getDataFromDB(keyName: IS_REGISTERED))")
        tableEndTrip.reloadData()
        menuTableView.reloadData()
    }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[BookingComfortViewController] : \(#function)")
        self.view.endEditing(true)
    }

    @IBAction func doBooking(_ sender: Any) {
        print("dobook")
//        let cfa = TestVKey(viewController: self)
//        DispatchQueue.global().async() {
//            do {
//                try ExceptionCatcher.catchException {
//                    cfa.invoke({ (result) in
//                        print("result success = \(result)")
//
//                    }, failure: { (error) in
//                        print("failed responseCode = " + error)
//                    })
//                }
//            } catch {
//                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
//                    print(error.localizedDescription)
//                }
//            }
//        }
        
        let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
        if isReg.count == 0 || isReg == "0" {
            print("showError Message")
            self.showErrorMessage(responderCode: "", errorCode: "U002", errorMessage: "Payment has not been registered")
            return
        }

        guard let amount = bookAmount.text else {
            self.showErrorMessage(responderCode: "", errorCode: "U001", errorMessage: "Amount must be more than 0")
            return
        }

        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        print(amountDouble)
        if Double(amountDouble)! <= 0.0 {
            self.showErrorMessage(responderCode: "", errorCode: "U001", errorMessage: "Amount must be more than 0")
            return
        }


        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        self.showLoading()
        let cfa = CheckFundAvailability(estimatedTxnAmount: b)
        DispatchQueue.global().async() {
            do {
                try ExceptionCatcher.catchException {
                    
                    cfa.invoke({ (result) in
                        print("result success = \(result)")
                        self.table0205 = result
                        UserDefaults.standard.set(self.table0205, forKey: "table0205")
                        self.submitCFA(amount: b, txnType: self.TXN_CFA)

                    }, failure: { (error) in
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                OperationQueue.main.addOperation {
                                    self.showErrorMessage(responderCode: "", errorCode: error, errorMessage: "")
                                }
                            })
                        }
                        print("failed responseCode = " + error)
                    })
                }
            } catch {
                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    @IBAction func openSideMenu(_ sender: Any) {
        self.view.endEditing(true)
        if menuShowing {
            leadingConstraint.constant = -208
        } else {
            leadingConstraint.constant = 0
            UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseIn, animations: {
                self.view.layoutIfNeeded()
            }) { (completed) in
                // not used
            }
            
        }
        menuShowing = !menuShowing
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if (event?.subtype == UIEvent.EventSubtype.motionShake) {
            getDataFromDocumentDirectory()
        }
    }
    
    func getDataFromDocumentDirectory() {
        let documentDirectory = FileManager.SearchPathDirectory.documentDirectory
        let userDomainMask = FileManager.SearchPathDomainMask.userDomainMask
        let paths = NSSearchPathForDirectoriesInDomains(documentDirectory, userDomainMask, true)
        if let dirPath = paths.first {
//            let vtapURL = URL(fileURLWithPath: dirPath).appendingPathComponent("vtap.db")
            let vguardURL = URL(fileURLWithPath: dirPath).appendingPathComponent("vguard.db")
            let activityController = UIActivityViewController(activityItems: [vguardURL], applicationActivities: nil)
            self.present(activityController, animated: true, completion: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == menuTableView {
            let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
            if isReg.count == 0 || isReg == "0" {
                return arrayMenu_beforeReg.count
            } else {
                return arrayMenu.count
            }
        } else if tableView == tableEndTrip {
            let titleMenu = self.bookingListTitle.text
            if titleMenu == self.arrayMenu[1] {
                return arrayBooking.count
            } else if titleMenu == self.arrayMenu[3] {
                return arrayTxnHistory.count
            }
            
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tableEndTrip {
            return 90.0
        }
        return 45.0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == menuTableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
            
            // Configure the cell...
            let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
            if isReg.count == 0 || isReg == "0" {
                let menuTitle = arrayMenu_beforeReg[indexPath.row]
                cell.textLabel?.text = menuTitle
            } else {
                let menuTitle = arrayMenu[indexPath.row]
                cell.textLabel?.text = menuTitle
            }
            
            return cell
        } else if tableView == tableEndTrip {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tableEndTripCell", for: indexPath)
            
            // Configure the cell...
            let titleMenu = self.bookingListTitle.text
            if titleMenu == self.arrayMenu[1] {
                let bookData = arrayBooking[indexPath.row]
                cell.textLabel?.text = "AMOUNT : \(bookData.bookingAmount)"
                cell.detailTextLabel?.numberOfLines = 4
                let txnTime = "\(bookData.bookingTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(bookData.bookingTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(bookData.bookingTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
                cell.detailTextLabel?.text = "AUTH CODE : \(bookData.bookingAuthCode)\nBOOKING TIME : \(bookData.bookingDate) \(txnTime)\nRRN : \(bookData.bookingRrn)\nTID : \(bookData.bookingTid)"
            } else if titleMenu == self.arrayMenu[3] {
                let bookData = arrayTxnHistory[indexPath.row]
                cell.textLabel?.text = "AMOUNT : \(bookData.bookingAmount)"
                cell.detailTextLabel?.numberOfLines = 4
                let txnTime = "\(bookData.bookingTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(bookData.bookingTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(bookData.bookingTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
                cell.detailTextLabel?.text = "AUTH CODE : \(bookData.bookingAuthCode)\nBOOKING TIME : \(bookData.bookingDate) \(txnTime)\nRRN : \(bookData.bookingRrn)\nTID : \(bookData.bookingTid)"
            }
            
            
            return cell
        }
        return tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if (tableView == menuTableView) {
            if indexPath.row == 0 {
                bookingView.isHidden = false
                endTripView.isHidden = true
            } else if indexPath.row == 1 {
                bookingView.isHidden = true
                endTripView.isHidden = false
                bookingListTitle.text = self.arrayMenu[indexPath.row]
                arrayBooking = self.getArrayFromDB(keyName: BOOKING_KEY)
                tableEndTrip.reloadData()
            } else if indexPath.row == 2 {
                self.performSegue(withIdentifier: "managePaymentBook", sender: self)
            } else if indexPath.row == 3 {
                let isReg = self.getDataFromDB(keyName: IS_REGISTERED)
                if isReg.count == 0 || isReg == "0" {
                    self.storeDataToDB(keyValue: "", keyName: IS_CHOOSE_TYPE)
                    let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let exampleViewController: UINavigationController = mainStoryboard.instantiateViewController(withIdentifier: "navigationType") as! UINavigationController
                    //                let navigationController = UINavigationController(rootViewController: exampleViewController)
                    UIApplication.shared.keyWindow?.rootViewController = exampleViewController
                    
                    UIApplication.shared.keyWindow?.makeKeyAndVisible()
                } else {
                    bookingView.isHidden = true
                    endTripView.isHidden = false
                    bookingListTitle.text = self.arrayMenu[indexPath.row]
                    arrayTxnHistory = self.getArrayFromDB(keyName: TXN_HISTORY_KEY)
                    tableEndTrip.reloadData()
//                self.performSegue(withIdentifier: "updateMuidDetails", sender: self)
                }

            } else if indexPath.row == 4 {
                
            }
            self.openSideMenu(self)
        } else if tableView == tableEndTrip {
            let titleMenu = self.bookingListTitle.text
            if titleMenu == self.arrayMenu[1] {
                selectedIdx = indexPath.row
                self.performSegue(withIdentifier: "endTripDetails", sender: self)
            } else if titleMenu == self.arrayMenu[3] {
                // txn history
                selectedIdx = indexPath.row
                self.performSegue(withIdentifier: "showTxnHistoryDetail", sender: self)
            }
//            arrayBooking.remove(at: indexPath.row)
//            self.saveArrayToDB(keyName: BOOKING_KEY)
//            tableEndTrip.reloadData()
        }
    }
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayBooking) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayBooking)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: BOOKING_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func getArrayFromDB(keyName: String) -> [Booking] {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName)
        if let jsonData = strData?.data(using: String.Encoding.utf8) {
            let jsonDecoder = JSONDecoder()
            do {
                let arrayBooking = try jsonDecoder.decode([Booking].self, from: jsonData)
                return arrayBooking
            } catch let error {
                print(error)
                return [Booking]()
            }
        }
        return [Booking]()
    }
    
    func getArrayFromDB(keyName: String) -> [TransactionHistory] {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName)
        if let jsonData = strData?.data(using: String.Encoding.utf8) {
            let jsonDecoder = JSONDecoder()
            do {
                let arrayBooking = try jsonDecoder.decode([TransactionHistory].self, from: jsonData)
                return arrayBooking
            } catch let error {
                print(error)
                return [TransactionHistory]()
            }
        }
        return [TransactionHistory]()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewController = segue.destination as? EndTripDetailViewController {
            viewController.selectedIdx = selectedIdx
            viewController.arrayBooking = arrayBooking
            viewController.muid = muid
        } else if let viewController = segue.destination as? UpdateMuidViewController {
            viewController.muid = muid
        } else if let viewController = segue.destination as? ManagePaymentViewController {
            viewController.muid = muid
        } else if let viewController = segue.destination as? TxnHistoryDetailViewController {
            viewController.selectedIdx = selectedIdx
            viewController.arrayTxnHistory = arrayTxnHistory
            viewController.muid = muid
        }
    }
    
    func submitCFA(amount: String, txnType: Int) {
        
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        if self.chooseType == "0" || self.chooseType == "1" {
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        var url = "\(host)\(MERCHANT_HOST_URL_CFA)"
        
        if txnType == TXN_DEBIT {
            url = "\(host)\(MERCHANT_HOST_URL_DIRECT_PURCHASE)"
        }
        
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        if let c = UserDefaults.standard.string(forKey: "table0205") {
            DispatchQueue.main.async{
                self.showLoading()
            }
            var url = URLComponents(string: url)!
            
            url.queryItems = [
                URLQueryItem(name: "mid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)),
                URLQueryItem(name: "tid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN))
            ]
            
            let request = URLRequest(url: url.url!)
           
            let json: [String: Any] = ["t0205": c, "amt": amount, "muid": muid, "muuid": muuid!]
            NetworkHandler.requestServer(json: json, req: request) { (response, error) in
                DispatchQueue.main.async{
                    if let err = error {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                            })
                        }
                        return
                    }
                    if let jsonResponse = response {
                        guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                            return
                        }
                        if strResponseCode != "00" && jsonResponse["responder"] == nil {
                            self.dismiss(animated: true, completion: {
                                if txnType == self.TXN_CFA {
                                        self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "CFA Failed")
                                } else if (txnType == self.TXN_DEBIT) {
                                        self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Purchase Failed")
                                }
                            })
                            return
                        }
                        guard let strT53: String = jsonResponse["t5253"] as? String else {
                            return
                        }
                        guard let strAuthCode: String = jsonResponse["authCode"] as? String else {
                            return
                        }
                        guard let strResponder: String = jsonResponse["responder"] as? String else {
                            return
                        }
                        
                        if strResponseCode == "00" {
                            guard let amount = self.bookAmount.text else {
                                return
                            }
                            let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
                            if Double(amountDouble)! <= 0.0 {
                                return
                            }
                            let currentDate = Date()
                            let format = DateFormatter()
                            format.dateFormat = "yyyy-MM-dd"
                            let formattedDate = format.string(from: currentDate)
                            let book = Booking()
                            book.bookingAmount = amount
                            book.bookingAuthCode = strAuthCode
                            book.bookingDate = formattedDate
                            guard let txnTime: String = jsonResponse["transactionTime"] as? String else {
                                return
                            }
                            book.bookingTime = txnTime
                            guard let txnTid: String = jsonResponse["tid"] as? String else {
                                return
                            }
                            book.bookingTid = txnTid.replacingOccurrences(of: " ", with: "")
                            
                            guard let txnMid: String = jsonResponse["mid"] as? String else {
                                return
                            }
                            book.bookingMid = txnMid.replacingOccurrences(of: " ", with: "")
                            guard let txnRrn: String = jsonResponse["rrn"] as? String else {
                                return
                            }
                            book.bookingRrn = txnRrn.replacingOccurrences(of: " ", with: "")
                            self.arrayBooking.append(book)
                            self.saveArrayToDB(keyName: self.BOOKING_KEY)
                        }
                        var table53 = strT53
                        if strT53.count == 183 {
                            table53 = table53.myOwnSubstring(startIndex: 78, endIndex: table53.count)
                        }
                        print("Table 53 count = \(table53.count)")
                        print("Table 53 = \(table53)")
                        self.handleResponsePurchase(respCode: strResponseCode, t53: table53, txnType: txnType, responderCode:  strResponder)
                    }
                }
            }
        }
    }
    
    func showErrorMessage(responderCode: String, errorCode :String, errorMessage :String) {
        if errorCode == "00" {
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Status : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Status : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
//                self.storeDataToDB(keyValue: "0", keyName: self.IS_REGISTERED)
                let titleMenu = self.bookingListTitle.text
                if titleMenu == "Book a Cab" {
                } else {
                    self.navigationController?.dismiss(animated: true, completion: nil)
                }
            }))
            present(alertController, animated: true, completion: nil)
            
        } else if errorCode == "U002" {
            let alertController = UIAlertController(title: "Error : \(errorCode)", message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                self.performSegue(withIdentifier: "managePaymentBook", sender: self)
//                self.navigationController?.dismiss(animated: true, completion: nil)
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9982")  {
                errMsg = "\(errMsg) - Invalid transaction amount"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Error : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Error : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errMsg, preferredStyle: .alert)
            
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    
    func handleResponsePurchase(respCode: String, t53: String, txnType: Int, responderCode: String) {
        guard let amount = bookAmount.text else {
            return
        }
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            return
        }
        
        let c = (Double(amountDouble)! * 100.0)
        let d = Int(c)
        let b = String(format: "%012d", d)
        print("B = \(b)")
        if respCode == "U9" || respCode == "55" {
            //
            self.dismiss(animated: true, completion: {
                if (txnType == self.TXN_CFA) {
                    let cfa = CheckFundAvailability(estimatedTxnAmount: b, withResponseCode: respCode, withTransactionCryptogram: t53, with: self)
                    DispatchQueue.global().async() {
                        do {
                            try ExceptionCatcher.catchException {
                                //                            self.showLoading()
                                cfa.invoke({ (result) in
                                    print("result success = \(result)")
                                    self.table0205 = result
                                    UserDefaults.standard.set(self.table0205, forKey: "table0205")
                                    //                                self.dismiss(animated: true, completion: {
                                    DispatchQueue.main.async() {
                                        self.submitCFA(amount: b, txnType: self.TXN_CFA)
                                    }
                                    //                                })
                                }, failure: { (error) in
                                    DispatchQueue.main.async() {
                                        self.dismiss(animated: true, completion: {
                                            OperationQueue.main.addOperation {
                                                self.showErrorMessage(responderCode: "", errorCode: error, errorMessage: "")
                                            }
                                        })
                                        print("failed responseCode = " + error)
                                    }
                                    //                                })
                                })
                            }
                        } catch {
                            if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                                print(error.localizedDescription)
                            }
                            DispatchQueue.main.async() {
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(responderCode: "", errorCode: "", errorMessage: error.localizedDescription)
                                })
                            }
                        }
                    }
                } else if (txnType == self.TXN_DEBIT) {
                    // will be implemented later
                    //                let debit = Debit(amount: "000000000100")
                    //                do {
                    //                    try ExceptionCatcher.catchException {
                    //                        self.showLoading()
                    //                        debit.invoke({ (result) in
                    //                            print("result success = \(result)")
                    //                            self.table0205 = result
                    //                            UserDefaults.standard.set(self.table0205, forKey: "table0205")
                    //                            self.submitCFA(amount: "100", txnType: self.TXN_DEBIT)
                    //                            self.hideLoading()
                    //                        }, failure: { (error) in
                    //                            self.showErrorMessage(errorCode: error, errorMessage: "")
                    //                            print("failed responseCode = " + error)
                    //                            self.hideLoading()
                    //                        })
                    //                    }
                    //                } catch {
                    //                    if error.localizedDescription == ServiceError.serviceNotInitializedException().reason {
                    //                        print(error.localizedDescription)
                    //                    }
                    //                }
                }
            })
        } else if respCode == "75" {
            self.dismiss(animated: true, completion: {
                self.showErrorMessage(responderCode: responderCode, errorCode: respCode, errorMessage: "Pin Retry Limit Exceeded")
            })
        } else {
            self.dismiss(animated: true, completion: {
                if txnType == self.TXN_CFA {
                    if respCode == "00" {
                        self.showErrorMessage(responderCode: responderCode, errorCode: "00", errorMessage: "CFA Success")
                    } else {
                        self.showErrorMessage(responderCode: responderCode, errorCode: respCode, errorMessage: "CFA Failed")
                    }
                } else if (txnType == self.TXN_DEBIT) {
                    if respCode == "00" {
                        self.showErrorMessage(responderCode: responderCode, errorCode: "00", errorMessage: "Purchase Success")
                    } else {
                        self.showErrorMessage(responderCode: responderCode, errorCode: respCode, errorMessage: "Purchase Failed")
                    }
                }
            })
        }
    }
    
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    
    
    func storeDataToDB(keyValue: String, keyName: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }
}

