//
//  TxnHistoryDetailViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 28/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import Foundation

class TxnHistoryDetailViewController: UIViewController {
    
    let MERCHANT_HOST_URL_PURCHASE_REVERSAL = "/nof/purchasereversal"
    let MERCHANT_HOST_URL_PURCHASE_REFUND = "/nof/refund"
    let MERCHANT_HOST_URL_PURCHASE_REFUND_REVERSAL = "/nof/refundreversal"
    
    var selectedIdx: Int = -1
    var arrayTxnHistory: [TransactionHistory] = []
    var arrayTxnRefund: [RefundTransaction] = []
    
    let BOOKING_KEY = "NOF_BOOKING"
    let TXN_HISTORY_KEY = "NOF_TXN_HISTORY"
    let MERCHANT_UID = "MERCHANT_UID"
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    
    var TxnDate = ""
    var TxnTime = ""
    var AuthCode = ""
    var RRN = ""
    var TID = ""
    var Amount = ""
    var txnInitiated = ""
    var Status = ""
    
    var t_TxnDateTime = ""
    var t_AuthCode = ""
    var t_RRN = ""
    var t_TID = ""
    var t_Amount = ""
    var t_Status = ""
    
    var muid = ""
    var mid = ""
    var tid = ""
    var chooseType = ""
    @IBOutlet weak var bookingDateTimeTitle: UILabel!
    @IBOutlet weak var bookingAuthCodeTitle: UILabel!
    @IBOutlet weak var bookingRrnTitle: UILabel!
    @IBOutlet weak var bookingTidTitle: UILabel!
    @IBOutlet weak var bookingAmtTitle: UILabel!
    @IBOutlet weak var statusTitle: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        muid = self.getDataFromDB(keyName: MERCHANT_UID)
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let add = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(showMenu))
        self.navigationItem.rightBarButtonItem = add
        
        t_TxnDateTime = bookingDateTimeTitle.text!
        t_AuthCode = bookingAuthCodeTitle.text!
        t_RRN = bookingRrnTitle.text!
        t_TID = bookingTidTitle.text!
        t_Amount = bookingAmtTitle.text!
        t_Status = statusTitle.text!
        
        refreshData()
        
        bookingDateTimeTitle.isUserInteractionEnabled = true
        bookingDateTimeTitle.tag = 1001
        bookingDateTimeTitle.addGestureRecognizer(setGesture())
        
        bookingAuthCodeTitle.isUserInteractionEnabled = true
        bookingAuthCodeTitle.tag = 1002
        bookingAuthCodeTitle.addGestureRecognizer(setGesture())
        
        bookingRrnTitle.isUserInteractionEnabled = true
        bookingRrnTitle.tag = 1003
        bookingRrnTitle.addGestureRecognizer(setGesture())
        
        bookingTidTitle.isUserInteractionEnabled = true
        bookingTidTitle.tag = 1004
        bookingTidTitle.addGestureRecognizer(setGesture())
        
        bookingAmtTitle.isUserInteractionEnabled = true
        bookingAmtTitle.tag = 1005
        bookingAmtTitle.addGestureRecognizer(setGesture())
        // Do any additional setup after loading the view.
    }
    
    func refreshData() {
        let bookData = arrayTxnHistory[selectedIdx]
        let txnTime = "\(bookData.bookingTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(bookData.bookingTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(bookData.bookingTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
        
        self.arrayTxnRefund.removeAll()
        
        let refundData = bookData.refundTxn
        for rf in refundData {
            self.arrayTxnRefund.append(rf)
        }
        print("Refund = \(refundData)")
        TxnTime = txnTime
        TxnDate = bookData.bookingDate
        AuthCode = bookData.bookingAuthCode
        RRN = bookData.bookingRrn
        TID = bookData.bookingTid
        Amount = bookData.bookingAmount
        Status = bookData.statusTxn
        txnInitiated = ""
        
        
        
        loadData()
        
        mid = bookData.bookingMid
        tid = bookData.bookingTid
    }
    
    func setGesture() -> UITapGestureRecognizer {
         let myRecognizer = UITapGestureRecognizer(target: self, action: #selector(editFields(_sender:)))
         return myRecognizer
    }
    
    func loadData() {
        bookingDateTimeTitle.text = "\(t_TxnDateTime) \(TxnDate) \(TxnTime)"
        bookingAuthCodeTitle.text = "\(t_AuthCode) \(AuthCode)"
        bookingRrnTitle.text = "\(t_RRN) \(RRN)"
        bookingTidTitle.text = "\(t_TID) \(TID)"
        bookingAmtTitle.text = "\(t_Amount) \(Amount)"
        statusTitle.text = "\(t_Status) \(Status)"
    }
    
    @objc func editFields(_sender: UITapGestureRecognizer) {
        print("sender = \(_sender)")
        if _sender.view?.tag == 1001 {
            let title = t_TxnDateTime
            let defValue = "\(TxnDate) \(TxnTime)"
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1002 {
            let title = t_AuthCode
            let defValue = AuthCode
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1003 {
            let title = t_RRN
            let defValue = RRN
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1004 {
            let title = t_TID
            let defValue = TID
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
        
        if _sender.view?.tag == 1005 {
            let title = t_Amount
            let defValue = Amount
            showInput(title: title, defaultVal: defValue, tag: _sender.view!.tag)
        }
    }
   
    func showInput(title: String, defaultVal: String, tag: Int) {
        //1. Create the alert controller.
        let alert = UIAlertController(title: "", message: title, preferredStyle: .alert)


        //2. Add the text field. You can configure it however you need.
        alert.addTextField { (textField) in
            textField.text = defaultVal
            if tag == 1005 {
                textField.keyboardType = UIKeyboardType.numbersAndPunctuation
            } else if tag == 1002  || tag == 1003 || tag == 1004 {
                textField.keyboardType = UIKeyboardType.numberPad
            }
        }

        // 3. Grab the value from the text field, and print it when the user clicks OK.
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { [weak alert] (_) in
        }))

        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            let textField = alert?.textFields![0]
            if tag == 1001 {
                if let str = textField?.text {
                    if let str = textField?.text {
                        let dt = str.split(separator: " ")
                        if (dt.count > 1) {
                            let str = dt[0].split(separator: "-")
                            if str.count > 2 {
                                self.TxnDate = "\(dt[0])"
                            }
                            let str2 = dt[1].split(separator: ":")
                            if str2.count > 2 {
                                self.TxnTime = "\(dt[1])"
                            }
                        }
                        self.loadData()
                    }
                }
            }
            if tag == 1002 {
                if let str = textField?.text {
                    self.AuthCode = str
                    self.loadData()
                }
            }
            
            if tag == 1003 {
                if let str = textField?.text {
                    self.RRN = str
                    self.loadData()
                }
            }
            
            if tag == 1004 {
                if let str = textField?.text {
                    self.TID = str
                    self.loadData()
                }
            }
            
            if tag == 1005 {
                if let str = textField?.text {
                   if str.count == 0 && !str.starts(with: "$") { return }
                     
                    let amountDouble = str.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
                    print(amountDouble)
                    guard let _ = Double(amountDouble) else {
                        return
                    }
                    self.Amount = str
                    self.loadData()
                }
            }
            
            if tag == 1100 {
                if let str = textField?.text {
                    self.txnInitiated = str
                }
            }
            //print(textField)
        }))
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)

    }
    
    @IBAction func doReversal(_ sender: Any) {
        
        self.showLoading()
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        if self.chooseType == "0" || self.chooseType == "1" {
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        let url = URLComponents(string: "\(host)\(self.MERCHANT_HOST_URL_PURCHASE_REVERSAL)")!
        let request = URLRequest(url: url.url!)
        let json: [String: Any] = ["muid": muid, "muuid": muuid!, "authCode": arrayTxnHistory[selectedIdx].bookingAuthCode]
        
        NetworkHandler.requestServer(json: json, req: request) { (response, error) in
            DispatchQueue.main.async{
                if let err = error {
                    DispatchQueue.main.async{
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode:"", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                        })
                    }
                    return
                }
                if let jsonResponse = response {
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
                        self.arrayTxnHistory.remove(at: self.selectedIdx)
                        self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Reversal Purchase Success", isNeedBack: true)
                            })
                        }
                    } else {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Reversal Purchase failed")
                            })
                        }
                    }
                }
            }
        }
    }
    
    func showErrorMessage(responderCode: String, errorCode :String, errorMessage :String, isNeedBack: Bool = false) {
        if errorCode == "00" {
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Status : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Status : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                
                if isNeedBack {
                    self.navigationController?.popViewController(animated: true)
                }
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            var statusHeader = ""
            if responderCode.count > 0 {
                statusHeader = "Error : \(responderCode)-\(errorCode)"
            } else {
                statusHeader = "Error : \(errorCode)"
            }
            let alertController = UIAlertController(title: statusHeader, message: errMsg, preferredStyle: .alert)
            
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    
    
    func saveTxnHistoryArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayTxnHistory) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayTxnHistory)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: keyName)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }
    
    
    @IBAction func doRefund(_ sender: Any) {
        print("REFUND")
        
        self.showLoading()
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        
        if chooseType == "0" || chooseType == "1" {
            // ISO
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        
        var url = URLComponents(string: "\(host)\(self.MERCHANT_HOST_URL_PURCHASE_REFUND)")!
        
        url.queryItems = [
            URLQueryItem(name: "mid", value: mid),
            URLQueryItem(name: "tid", value: tid)
        ]
        let request = URLRequest(url: url.url!)
        
        let amt = convertAmountToStr(amount: Amount)
        let tDate = convertTxnDateToStr(txnDate: TxnDate)
        let tTime = convertTxnTimeToStr(txnTime: TxnTime)
        let json: [String: Any] = ["muid": muid, "muuid": muuid!, "authCode": AuthCode, "rrn": RRN, "tid": TID, "amount": amt, "txnDate": tDate, "txnTime": tTime, "xmit_datetime": txnInitiated]
        NetworkHandler.requestServer(json: json, req: request) { (response, error) in
            DispatchQueue.main.async{
                if let err = error {
                    DispatchQueue.main.async{
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode:"", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                        })
                    }
                    return
                }
                if let jsonResponse = response {
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode: "", errorCode: "", errorMessage: "Missing Response Code")
                        })
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
                        //                                self.arrayTxnHistory.remove(at: self.selectedIdx)
                        //                                self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
                        DispatchQueue.main.async{
                            guard let strAuthCode: String = jsonResponse["authCode"] as? String else {
                                return
                            }
                            guard let strMid: String = jsonResponse["mid"] as? String else {
                                return
                            }
                            guard let strRrn: String = jsonResponse["rrn"] as? String else {
                                return
                            }
                            guard let strTid: String = jsonResponse["tid"] as? String else {
                                return
                            }
                            guard let strTransDate: String = jsonResponse["transactionDate"] as? String else {
                                return
                            }
                            guard let strTransTime: String = jsonResponse["transactionTime"] as? String else {
                                return
                            }
                            
                            let refundTxn = RefundTransaction()
                            refundTxn.refundAmount = self.Amount
                            refundTxn.refundAuthCode = strAuthCode
                            refundTxn.refundMid = strMid
                            refundTxn.refundRrn = strRrn
                            refundTxn.refundTid = strTid
                            refundTxn.refundDate = strTransDate
                            refundTxn.refundTime = strTransTime
                            self.arrayTxnRefund.append(refundTxn)
                            self.arrayTxnHistory[self.selectedIdx].refundTxn = self.arrayTxnRefund
                            self.arrayTxnHistory[self.selectedIdx].statusTxn = "REFUNDED"
                            self.saveArrayTxnHistoryToDB(keyName: self.TXN_HISTORY_KEY)
                            self.Status = "REFUNDED"
                            self.loadData()
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Refund Purchase Success")
                            })
                        }
                    } else {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Refund Purchase failed")
                            })
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func doRefundReversal(_ sender: Any) {
        print("REFUND REVERSAL")
        
        self.showLoading()
        let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
        var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
        
        if chooseType == "0" || chooseType == "1" {
            // ISO
            host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
        }
        
        var url = URLComponents(string: "\(host)\(self.MERCHANT_HOST_URL_PURCHASE_REFUND_REVERSAL)")!
        
        url.queryItems = [
            URLQueryItem(name: "mid", value: mid),
            URLQueryItem(name: "tid", value: tid)
        ]
        let request = URLRequest(url: url.url!)
        let amt = convertAmountToStr(amount: Amount)
        let tDate = convertTxnDateToStr(txnDate: TxnDate)
        let tTime = convertTxnTimeToStr(txnTime: TxnTime)
        let json: [String: Any] = ["muid": muid, "muuid": muuid!, "authCode": AuthCode, "rrn": RRN, "tid": TID, "amount": amt, "txnDate": tDate, "txnTime": tTime, "xmit_datetime": txnInitiated]
        NetworkHandler.requestServer(json: json, req: request) { (response, error) in
            DispatchQueue.main.async{
                if let err = error {
                    DispatchQueue.main.async{
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode:"", errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                        })
                    }
                    return
                }
                if let jsonResponse = response {
                    guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                        self.dismiss(animated: true, completion: {
                            self.showErrorMessage(responderCode: "", errorCode: "", errorMessage: "Missing Response Code")
                        })
                        return
                    }
                    print("STR_RESPONSE_CODE = \(strResponseCode)")
                    if strResponseCode == "00" {
                        //                                self.arrayTxnHistory.remove(at: self.selectedIdx)
                        //                                self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
                        DispatchQueue.main.async{
                            var idx = -1
                            for i in 0 ..< self.arrayTxnRefund.count {
                                let rv = self.arrayTxnRefund[i]
                                if rv.refundAuthCode == self.AuthCode {
                                    idx = i
                                    break
                                }
                            }
                            if idx >= 0 {
                                self.arrayTxnRefund.remove(at: idx)
                            }
                            self.arrayTxnHistory[self.selectedIdx].refundTxn = self.arrayTxnRefund
                            self.arrayTxnHistory[self.selectedIdx].statusTxn = "REFUND_REVERSED"
                            self.saveArrayTxnHistoryToDB(keyName: self.TXN_HISTORY_KEY)
                            self.Status = "REFUND_REVERSED"
                            self.loadData()
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Refund Reversal Purchase Success")
                            })
                        }
                    } else {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(responderCode: "", errorCode: strResponseCode, errorMessage: "Refund Reversal Purchase failed")
                            })
                        }
                    }
                }
            }
        }
    }
    
    func convertAmountToStr(amount: String) -> String {
        let amountDouble = amount.replacingOccurrences(of: "$", with: "").replacingOccurrences(of: ",", with: "")
        if Double(amountDouble)! <= 0.0 {
            return "000000000000"
        }
        var amountD = amountDouble
        let c = amountDouble.split(separator: ".")
        
        if ( c.count > 1) {
            if c[1].count > 2 {
                let d: String = "\(c[1])"
                amountD = "\(c[0])\(d.myOwnSubstring(startIndex:0, endIndex:2))"
            } else if c[1].count == 1 {
                let d: String = "\(c[1])"
                amountD = "\(c[0])\(d.myOwnSubstring(startIndex:0, endIndex:1))0"
            } else {
                amountD = "\(c[0])\(c[1])"
            }
        } else if (c.count == 1) {
            amountD = "\(c[0])00"
        }
        let amountCent  = amountD.replacingOccurrences(of: ".", with: "")
        let cent = Int(amountCent)!
        print("TEST = \(cent)")
//        let d = Int(c)
        let b = String(format: "%012d", cent)
        return b
    }
    
    func convertTxnDateToStr(txnDate: String) -> String {
        let str = txnDate.split(separator: "-")
        print(str)
        let b = "\(str[1])\(str[2])"
        return b
    }
    
    func convertTxnTimeToStr(txnTime: String) -> String {
        let str = txnTime.split(separator: ":")
        let b = "\(str[0])\(str[1])\(str[2])"
        return b
    }
    
    func saveArrayTxnHistoryToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayTxnHistory) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayTxnHistory)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: TXN_HISTORY_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    @objc func showMenu() {
        let controller = UIAlertController(title: "Select Data To Load", message: nil, preferredStyle: UIAlertController.Style.actionSheet)

        controller.addAction(UIAlertAction(title: "Original Data", style: UIAlertAction.Style.default, handler: { action in
            self.refreshData()
        }))
        
        
        for abc in self.arrayTxnRefund {
            let v = abc.refundAuthCode
            controller.addAction(UIAlertAction(title: "REFUND - \(v)", style: UIAlertAction.Style.default, handler: { action in
                self.loadRefundData(refundData: abc)
            }))
        }
        controller.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))

        present(controller, animated: true, completion: nil)
    }
    
    func loadRefundData(refundData: RefundTransaction) {
        let currentDate = Date()
        let format = DateFormatter()
        format.dateFormat = "yyyy"
        let formattedDate = format.string(from: currentDate)
        
        let txnDate = "\(formattedDate)-\(refundData.refundDate.myOwnSubstring(startIndex: 0, endIndex: 2))-\(refundData.refundDate.myOwnSubstring(startIndex: 2, endIndex: 4))"
        
        let txnTime = "\(refundData.refundTime.myOwnSubstring(startIndex: 0, endIndex: 2)):\(refundData.refundTime.myOwnSubstring(startIndex: 2, endIndex: 4)):\(refundData.refundTime.myOwnSubstring(startIndex: 4, endIndex: 6))"
        TxnDate = txnDate
        TxnTime = txnTime
        AuthCode = refundData.refundAuthCode
        RRN = refundData.refundRrn
        TID = refundData.refundTid
        Amount = refundData.refundAmount
        Status = refundData.refundStatus
        
        bookingDateTimeTitle.text = "\(t_TxnDateTime) \(TxnDate) \(TxnTime)"
        bookingAuthCodeTitle.text = "\(t_AuthCode) \(AuthCode)"
        bookingRrnTitle.text = "\(t_RRN) \(RRN)"
        bookingTidTitle.text = "\(t_TID) \(TID)"
        if !Amount.contains("$") {
            Amount = "$\(Amount)"
        }
        bookingAmtTitle.text = "\(t_Amount) \(Amount)"
        statusTitle.text = "\(t_Status) \(Status)"
    }
}
