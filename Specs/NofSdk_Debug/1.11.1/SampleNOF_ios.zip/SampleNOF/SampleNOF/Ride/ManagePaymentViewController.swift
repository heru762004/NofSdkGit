//
//  ManagePaymentViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 14/6/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit

class ManagePaymentViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    let BOOKING_KEY = "NOF_BOOKING"
    let TXN_HISTORY_KEY = "NOF_TXN_HISTORY"
    let MERCHANT_TOKEN_BANK_FIID = "MERCHANT_TOKEN_BANK_FIID"
    let MERCHANT_TOKEN_EXPIRY = "MERCHANT_TOKEN_EXPIRY"
    let MERCHANT_TOKEN_LAST4PAN = "MERCHANT_TOKEN_LAST4PAN"
    let MERCHANT_TOKEN_STATUS = "MERCHANT_TOKEN_STATUS"
    
    let IS_REGISTERED = "IS_REGISTERED"
    let MERCHANT_UID = "MERCHANT_UID"
    var isRegistered = ""
    var muid = ""
    var merchantTokenBankFiid = ""
    var merchantTokenExpiry = ""
    var merchantTokenLast4Fpan = ""
    var merchantTokenStatus = ""
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    var chooseType = ""
    
    let MERCHANT_HOST_STATUS_CHECK = "/nof/statuscheck"
    
    var arrayBooking: [Booking] = []
    var arrayTxnHistory: [TransactionHistory] = []
    
    @IBOutlet weak var managePaymentTable: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isRegistered = self.getDataFromDB(keyName: IS_REGISTERED)
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
        managePaymentTable.reloadData()
        self.muid = self.getDataFromDB(keyName: MERCHANT_UID)
        if isRegistered.count == 0 || isRegistered == "0" {
        } else {
            if self.getDataFromDB(keyName: MERCHANT_TOKEN_BANK_FIID).count == 0
                && self.getDataFromDB(keyName: MERCHANT_TOKEN_EXPIRY).count == 0
                && self.getDataFromDB(keyName: MERCHANT_TOKEN_LAST4PAN).count == 0 {
                
                self.doStatusCheck()
            } else {
                self.merchantTokenBankFiid = self.getDataFromDB(keyName: MERCHANT_TOKEN_BANK_FIID)
                self.merchantTokenExpiry = self.getDataFromDB(keyName: MERCHANT_TOKEN_EXPIRY)
                self.merchantTokenLast4Fpan = self.getDataFromDB(keyName: MERCHANT_TOKEN_LAST4PAN)
                self.merchantTokenStatus = self.getDataFromDB(keyName: MERCHANT_TOKEN_STATUS)
            }
//            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Change `2.0` to the desired number of seconds.
//                // Code you want to be delayed
//
//            }
        }
    }
    override func viewDidLoad() {
        isRegistered = self.getDataFromDB(keyName: IS_REGISTERED)
        managePaymentTable.delegate = self
        managePaymentTable.dataSource = self
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "manageTableCell", for: indexPath)
        
        // Configure the cell...
        if isRegistered.count == 0 || isRegistered == "0" {
            cell.imageView?.image = UIImage(named: "simulator")
            cell.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
            cell.textLabel?.text = "Register NETS Click"
            cell.detailTextLabel?.text = ""
        } else {
            if merchantTokenBankFiid == "NCLC" {
                cell.imageView?.image = UIImage(named: "nets_card")
                cell.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
                cell.textLabel?.text = "\(merchantTokenLast4Fpan)"
                cell.detailTextLabel?.text = "EXPIRY (YYMM) : \(merchantTokenExpiry)\nSTATUS : \(merchantTokenStatus)"
                cell.detailTextLabel?.numberOfLines = 2
            } else if merchantTokenBankFiid == "DBSC" {
                cell.imageView?.image = UIImage(named: "dbs")//self.imageWithImage(image: UIImage(named: "dbs_posb_long")!, scaledToSize: CGSize(width: 100, height: 50))
                cell.imageView?.contentMode = .scaleAspectFit
//                cell.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
                cell.textLabel?.text = "\(merchantTokenLast4Fpan)"
                cell.detailTextLabel?.text = "EXPIRY (YYMM) : \(merchantTokenExpiry)\nSTATUS : \(merchantTokenStatus)"
                cell.detailTextLabel?.numberOfLines = 2
            } else if merchantTokenBankFiid == "UOBC" {
                cell.imageView?.image = UIImage(named: "uob")
                cell.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
                cell.textLabel?.text = "\(merchantTokenLast4Fpan)"
                cell.detailTextLabel?.text = "EXPIRY (YYMM) : \(merchantTokenExpiry)\nSTATUS : \(merchantTokenStatus)"
                cell.detailTextLabel?.numberOfLines = 2
            } else if merchantTokenBankFiid == "OCBC" {
                cell.imageView?.image = UIImage(named: "ocbc")
                cell.imageView?.contentMode = UIView.ContentMode.scaleAspectFit
                cell.textLabel?.text = "\(merchantTokenLast4Fpan)"
                cell.detailTextLabel?.text = "EXPIRY (YYMM) : \(merchantTokenExpiry)\nSTATUS : \(merchantTokenStatus)"
                cell.detailTextLabel?.numberOfLines = 2
            }
        }
        cell.imageView?.center = cell.center
//        cell.imageView?.center = CGPoint.init(x: cell.contentView.bounds.size.width/2, y: cell.contentView.bounds.size.height/2)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if isRegistered.count == 0 || isRegistered == "0" {
            return 80.0;
        }
        return 100.0;
    }
    
    func imageWithImage(image:UIImage,scaledToSize newSize:CGSize)->UIImage{
        
        UIGraphicsBeginImageContextWithOptions( newSize, false, 0 )
        image.draw(in: CGRect(x: 0,y: 0,width: newSize.width,height: newSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!.withRenderingMode(.alwaysTemplate)
    }

    
    func doDereg() {
        let dereg = Deregistration()
        self.showLoading()
        DispatchQueue.global().async() {
            do {
                try ExceptionCatcher.catchException {
                    dereg.invoke({ (result) in
                        print("result success = \(result)")
                        DispatchQueue.main.async() {
                            self.dismiss(animated: true, completion: {
                                OperationQueue.main.addOperation {
                                    self.saveArrayToDB(keyName: self.BOOKING_KEY)
                                    self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_BANK_FIID, keyValue: "")
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_EXPIRY, keyValue: "")
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_LAST4PAN, keyValue: "")
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_STATUS, keyValue: "")
                                    self.showErrorMessage(errorCode: "00", errorMessage: "Deregistration success")
                                }
                            })
                        }
                    }, failure: { (error) in
                        print("failed responseCode = " + error)
                        DispatchQueue.main.async() {
                            self.dismiss(animated: true, completion: {
                                OperationQueue.main.addOperation {
                                    self.showErrorMessage(errorCode: error, errorMessage: "Deregistration failed")
                                }
                            })
                        }
                    })
                }
            } catch {
                DispatchQueue.main.async() {
                    self.dismiss(animated: true, completion: {
                        let err: NSError = error as NSError
                        if error.localizedDescription == ServiceError.serviceNotInitializedException().reason {
                            print(error.localizedDescription)
                        }
                        if error.localizedDescription == ServiceError.missingServerCertException().name.rawValue {
                            print(error.localizedDescription)
                        }
                        if error.localizedDescription == ServiceError.missingDataException("").name.rawValue {
                            print(error.localizedDescription)
                            if let missingFields: String = err.userInfo["NSLocalizedDescriptionKey"] as? String {
                                DispatchQueue.main.async() {
                                    self.showErrorMessage(errorCode: "Error", errorMessage: "Missing Data : \(missingFields)")
                                    }
                            }
                        }
                    })
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if isRegistered.count == 0 || isRegistered == "0" {
            self.performSegue(withIdentifier: "showNofRegistration", sender: self)
//            self.doDereg()
        } else {
            self.doDereg()
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }
    
    func storeDataToDB(keyValue: String, keyName: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    
    func showErrorMessage(errorCode :String, errorMessage :String) {
        if errorCode == "00" {
            let alertController = UIAlertController(title: "Status : \(errorCode)", message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                self.storeDataToDB(keyValue: "0", keyName: self.IS_REGISTERED)
                self.isRegistered = "0"
                self.managePaymentTable.reloadData()
                self.navigationController?.dismiss(animated: true, completion: nil)
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            let alertController = UIAlertController(title: "Error : \(errorCode)", message: errMsg, preferredStyle: .alert)
            
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    
    
    func doStatusCheck() {
        
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: {
            let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
            var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
            if self.chooseType == "0" || self.chooseType == "1" {
                host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
            }
            var url = URLComponents(string: "\(host)\(self.MERCHANT_HOST_STATUS_CHECK)")!
            
            url.queryItems = [
                URLQueryItem(name: "mid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)),
                URLQueryItem(name: "tid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN))
            ]
            
            let request = URLRequest(url: url.url!)
            let json: [String: Any] = ["muid": self.muid, "muuid": muuid!]
            
            NetworkHandler.requestServer(json: json, req: request) { (response, error) in
                DispatchQueue.main.async{
                    if let err = error {
                        DispatchQueue.main.async{
                            self.dismiss(animated: true, completion: {
                                self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                            })
                        }
                        return
                    }
                    if let jsonResponse = response {
                        guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                            return
                        }
                        print("STR_RESPONSE_CODE = \(strResponseCode)")
                        if strResponseCode == "00" {
                            
                            DispatchQueue.main.async{
                                // do ui update here
                                self.dismiss(animated: true, completion: {
                                    if let bankFiid: String = jsonResponse["merchantTokenBankFiid"] as? String {
                                        self.merchantTokenBankFiid = bankFiid
                                    }
                                    if let tokenExpiry: String = jsonResponse["merchantTokenExpiry"] as? String {
                                        self.merchantTokenExpiry = tokenExpiry
                                    }
                                    if let last4Fpan: String = jsonResponse["merchantTokenLast4Fpan"] as? String {
                                        self.merchantTokenLast4Fpan = last4Fpan
                                    }
                                    if let tokenStatus: String = jsonResponse["merchantTokenStatus"] as? String {
                                        /*
                                         0 – Pre Registered, 1 – Blocked,
                                         2 – De-registered, 3 – Registered,
                                         4 – Suspended.
                                         */
                                        if(tokenStatus == "0") {
                                            self.merchantTokenStatus = "Pre Registered"
                                        } else if(tokenStatus == "1") {
                                            self.merchantTokenStatus = "Blocked"
                                        } else if(tokenStatus == "2") {
                                            self.merchantTokenStatus = "De-Registered"
                                        } else if(tokenStatus == "3") {
                                            self.merchantTokenStatus = "Registered"
                                        } else if(tokenStatus == "4") {
                                            self.merchantTokenStatus = "Suspended"
                                        } else {
                                            self.merchantTokenStatus = tokenStatus
                                        }
                                    }
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_BANK_FIID, keyValue: self.merchantTokenBankFiid)
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_EXPIRY, keyValue: self.merchantTokenExpiry)
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_LAST4PAN, keyValue: self.merchantTokenLast4Fpan)
                                    self.saveStringToDB(keyName: self.MERCHANT_TOKEN_STATUS, keyValue: self.merchantTokenStatus)
                                    self.managePaymentTable.reloadData()
                                })
                            }
                        } else {
                            DispatchQueue.main.async{
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(errorCode: strResponseCode, errorMessage: "Status Check failed")
                                })
                            }
                        }
                    }
                }
            }
        })
    }
    
    func getStringFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        if let result = defaults.string(forKey: keyName) {
            return result
        }
        return ""
    }
    
    func saveStringToDB(keyName: String, keyValue: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayBooking) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayBooking)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: BOOKING_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func saveTxnHistoryArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayTxnHistory) saved for \(keyName)")
        
        do {
            //            let jsonData = try jsonEncoder.encode(arrayTxnHistory)
            //            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set("", forKey: TXN_HISTORY_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }


}
