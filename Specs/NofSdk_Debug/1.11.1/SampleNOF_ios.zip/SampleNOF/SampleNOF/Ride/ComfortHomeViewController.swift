//
//  ComfortHomeViewController.swift
//  SampleNOF
//
//  Created by Heru Prasetia on 31/5/19.
//  Copyright © 2019 NETS. All rights reserved.
//

import UIKit

class ComfortHomeViewController: UIViewController, RegisterSuccessViewDelegate {
    let MERCHANT_HOST_URL_GMT       = "/nof/gmt"
    //internal ip HCESIT
    //    let HOST_URL                = "http://172.18.20.146:7201/mapserver/txn"
    
    let MERCHANT_TOKEN_BANK_FIID = "MERCHANT_TOKEN_BANK_FIID"
    let MERCHANT_TOKEN_EXPIRY = "MERCHANT_TOKEN_EXPIRY"
    let MERCHANT_TOKEN_LAST4PAN = "MERCHANT_TOKEN_LAST4PAN"
    
    // comfort RID : "11181300100"
    // master RID : "11180000100"
    var muid = ""//"hp286@yahoo.com"
    var table0102 = ""
    //    let muid = "user6@yahoo.com"
    
    let serverName = "netspayserver"
    
    var merchantTokenBankFiid = ""
    var merchantTokenExpiry = ""
    var merchantTokenLast4Fpan = ""
    
    let IS_INIT = "IS_INIT"
    let IS_REGISTERED = "IS_REGISTERED"
    let IS_REGISTERED_BEFORE = "IS_REGISTERED_BEFORE"
    let MERCHANT_UID = "MERCHANT_UID"
    let IS_CHOOSE_TYPE = "IS_CHOOSE_TYPE"
    
    var chooseType = ""
    
    @IBOutlet weak var bgView: UIImageView!
    
    @IBOutlet weak var leadingConstraint: NSLayoutConstraint!
    
    var menuShowing = false
    
    @IBOutlet weak var txtMuid: UITextField!
    
    @IBOutlet weak var txtMid: UILabel!
    
    let BOOKING_KEY = "NOF_BOOKING"
    let TXN_HISTORY_KEY = "NOF_TXN_HISTORY"
    
    var arrayBooking: [Booking] = []
    var arrayTxnHistory: [TransactionHistory] = []
    
    var registerSuccessView: RegisterSuccessViewController? = nil
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let isRegistered = self.getDataFromDB(keyName: IS_REGISTERED)
        let mUID = self.getDataFromDB(keyName: MERCHANT_UID)
        self.chooseType = self.getDataFromDB(keyName: IS_CHOOSE_TYPE)
        if mUID.count == 0 {
            self.txtMuid.text = muid
        } else {
            self.txtMuid.text = mUID
        }
        if isRegistered.count == 0 || isRegistered == "0" {
        } else {
            self.performSegue(withIdentifier: "registerSuccess", sender: self)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        txtMid.text = self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)
        let mUID = self.getDataFromDB(keyName: MERCHANT_UID)
        if mUID.count == 0 {
            self.txtMuid.text = muid
        } else {
            self.txtMuid.text = mUID
        }
        let tap = UITapGestureRecognizer(target: self,
                                         action: #selector(handleSingleTap(sender:)))
        
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let exampleViewController: RegisterSuccessViewController = mainStoryboard.instantiateViewController(withIdentifier: "registerSuccessVIew") as! RegisterSuccessViewController
        registerSuccessView = exampleViewController
        
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    @objc func handleSingleTap(sender: UITapGestureRecognizer) {
        print("[ComfortHomeViewController] : \(#function)")
        self.view.endEditing(true)
    }
    
    @IBAction func doRegister(_ sender: Any) {
        if (self.txtMuid.text == nil || self.txtMuid.text?.count == 0) {
            showErrorMessage(errorCode: "Error", errorMessage: "MUID must be filled")
            return
        }
        self.doRegistration()
    }
    
    func doUpdateMuid(newMuid: String) {
        print("do Update MUID")
        //        let updateMuid = UpdateMuid(muid: newMuid, andWith: self, withNavigationBarColor: UIColor(displayP3Red: 0, green: (128/255), blue: (247.0/255.0), alpha: 1.0), withTitleBarColor: UIColor.white)
        //        //        let updateMuid = UpdateMuid(muid: newMuid, andWith: self)
        //        DispatchQueue.global().async() {
        //            do {
        //                try ExceptionCatcher.catchException {
        //                    updateMuid.invoke({ (result) in
        //                        DispatchQueue.main.async() {
        //                            print("result success = \(result)")
        //                            self.storeDataToDB(keyValue: newMuid, keyName: self.MERCHANT_UID)
        //                            self.saveArrayToDB(keyName: self.BOOKING_KEY)
        //                            self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
        //                            let mUID = self.getDataFromDB(keyName: self.MERCHANT_UID)
        //                            print("new MUID = \(mUID)")
        //                            self.txtMuid.text = mUID
        //                            self.table0102 = result;
        //                            UserDefaults.standard.set(self.table0102, forKey: "table0102")
        //                            //                            self.hideLoading()
        //                            self.doGetMerchantToken()
        //                        }
        //                    }, failure: { (error) in
        //                        DispatchQueue.main.async() {
        //                            self.showErrorMessage(errorCode: error, errorMessage: "update muid failed")
        //                            print("failed responseCode = " + error)
        //                        }
        //                    })
        //                }
        //            } catch {
        //                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
        //                    print(error.localizedDescription)
        //                }
        //                DispatchQueue.main.async() {
        //                    self.dismiss(animated: true, completion: nil)
        //                }
        //            }
        //        }
    }
    
    
    func saveArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayBooking) saved for \(keyName)")
        let jsonEncoder = JSONEncoder()
        do {
            let jsonData = try jsonEncoder.encode(arrayBooking)
            let json = String(data: jsonData, encoding: String.Encoding.utf8)
            defaults.set(json, forKey: BOOKING_KEY)
            defaults.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    func saveTxnHistoryArrayToDB(keyName: String) {
        let defaults = UserDefaults.standard
        print("\(arrayTxnHistory) saved for \(keyName)")
        defaults.set("", forKey: TXN_HISTORY_KEY)
        defaults.synchronize()
    }
    
    @IBAction func closePage(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func doRegistration() {
        print("doRegister")
        guard let midStr = self.txtMid.text else {
            return;
        }
        
        guard let muidStr = self.txtMuid.text else {
            return;
        }
        
        var reg: Registration
//        let muidStr = ""
        if #available(iOS 10.0, *) {
            reg = Registration(viewController: self, withMuid: muidStr, andWithMid: midStr, withNavigationBarColor: UIColor(displayP3Red: 0, green: (128/255), blue: (247.0/255.0), alpha: 1.0), withTitleBarColor: UIColor.white)
        } else {
            // Fallback on earlier versions
            reg = Registration(viewController: self, withMuid: muidStr, andWithMid: midStr, withNavigationBarColor: UIColor.blue, withTitleBarColor: UIColor.white)
        }
        //        let reg = Registration(viewController: self)
        DispatchQueue.global().async() {
            do {
                try ExceptionCatcher.catchException {
                    //                 self.showLoading()
                    reg.invoke({ (result) in
                        DispatchQueue.main.async() {
                            print("result success = \(result)")
                            self.table0102 = result;
                            self.storeDataToDB(keyValue: muidStr, keyName: self.MERCHANT_UID)
                            self.saveArrayToDB(keyName: self.BOOKING_KEY)
                            self.saveTxnHistoryArrayToDB(keyName: self.TXN_HISTORY_KEY)
                            let mUID = self.getDataFromDB(keyName: self.MERCHANT_UID)
                            print("new MUID = \(mUID)")
                            self.txtMuid.text = mUID
                            UserDefaults.standard.set(self.table0102, forKey: "table0102")
                            //                            self.hideLoading()
                            self.doGetMerchantToken()
                        }
                    }, failure: { (error) in
                        DispatchQueue.main.async() {
                            self.showErrorMessage(errorCode: error, errorMessage: "registration failed")
                            print("failed responseCode = " + error)
                            //                            self.hideLoading()
                        }
                    })
                }
            } catch {
                //            DispatchQueue.main.async() {
                //                self.hideLoading()
                //            }
                let err: NSError = error as NSError
                if error.localizedDescription == ServiceError.serviceNotInitializedException().name.rawValue {
                    print(error.localizedDescription)
                }
                if error.localizedDescription == ServiceError.missingServerCertException().name.rawValue {
                    print(error.localizedDescription)
                }
                if error.localizedDescription == ServiceError.missingDataException("").name.rawValue {
                    print(error.localizedDescription)
                    if let missingFields: String = err.userInfo["NSLocalizedDescriptionKey"] as? String {
                        DispatchQueue.main.async() {
                            self.showErrorMessage(errorCode: "Error", errorMessage: "Missing Data : \(missingFields)")
                        }
                    }
                }
            }
        }
        
    }
    
    func doGetMerchantToken() {
        
        if let c = UserDefaults.standard.string(forKey: "table0102") {
            self.showLoading()
            let muuid = UIDevice.current.identifierForVendor?.uuidString.replacingOccurrences(of: "-", with:"")
            guard let muidStr = self.txtMuid.text else {
                return;
            }
            
            
            DispatchQueue.global().async() {
                var host = Utils.infoForKey("MERCHANT_HOST_URL_JSON")!
                if self.chooseType == "0" || self.chooseType == "1" {
                    host = Utils.infoForKey("MERCHANT_HOST_URL_ISO")!
                }
                var url = URLComponents(string: "\(host)\(self.MERCHANT_HOST_URL_GMT)")!
                url.queryItems = [
                    URLQueryItem(name: "mid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.MID_CHOOSEN)),
                    URLQueryItem(name: "tid", value: self.getDataFromDB(keyName: TypeMainMenuViewController.TID_CHOOSEN))
                ]
                
                let request = URLRequest(url: url.url!)
                
                let json: [String: Any] = ["t0102": c, "muid": muidStr, "muuid": muuid!]
                NetworkHandler.requestServer(json: json, req: request) { (response, error) in
                    DispatchQueue.main.async{
                        if let err = error {
                            DispatchQueue.main.async{
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(errorCode: "MERCHANT HOST ERROR", errorMessage: "\(err)")
                                })
                            }
                            return
                        }
                        if let jsonResponse = response {
                            guard let strResponseCode: String = jsonResponse["responseCode"] as? String else {
                                return
                            }
                            
                            if strResponseCode != "00" && jsonResponse["merchantTokenBankFiid"] == nil {
                                self.dismiss(animated: true, completion: {
                                    self.showErrorMessage(errorCode: strResponseCode, errorMessage: "GMT Failed")
                                })
                                return
                            }
                            
                            if let bankFiid: String = jsonResponse["merchantTokenBankFiid"] as? String {
                                self.merchantTokenBankFiid = bankFiid
                            }
                            if let tokenExpiry: String = jsonResponse["merchantTokenExpiry"] as? String {
                                self.merchantTokenExpiry = tokenExpiry
                            }
                            if let last4Fpan: String = jsonResponse["merchantTokenLast4Fpan"] as? String {
                                self.merchantTokenLast4Fpan = last4Fpan
                            }
                            
                            var message = ""
                            if strResponseCode == "00" {
                                message = "REGISTRATION SUCCESS"
                                self.storeDataToDB(keyValue: "1", keyName: self.IS_REGISTERED)
                                self.storeDataToDB(keyValue: "1", keyName: self.IS_REGISTERED_BEFORE)
                                self.storeDataToDB(keyValue: self.txtMuid.text!, keyName: self.MERCHANT_UID)
                                self.storeDataToDB(keyValue: self.merchantTokenBankFiid, keyName: self.MERCHANT_TOKEN_BANK_FIID)
                                self.storeDataToDB(keyValue: self.merchantTokenExpiry, keyName: self.MERCHANT_TOKEN_EXPIRY)
                                self.storeDataToDB(keyValue: self.merchantTokenLast4Fpan, keyName: self.MERCHANT_TOKEN_LAST4PAN)
                                DispatchQueue.main.async{
                                    self.dismiss(animated: true, completion: {
                                        OperationQueue.main.addOperation {
                                            
                                            self.registerSuccessView!.setDelegate(delegate: self)
                                            //                                            self.showErrorMessage(errorCode: strResponseCode, errorMessage: message)
                                            self.view.addSubview(self.registerSuccessView!.view)
                                        }
                                    })
                                    
                                }
                            } else {
                                message = "Get Merchant Token Failure"
                                DispatchQueue.main.async{
                                    self.dismiss(animated: true, completion: {
                                        OperationQueue.main.addOperation {
                                            self.showErrorMessage(errorCode: strResponseCode, errorMessage: message)
                                        }
                                    })
                                    
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    func showErrorMessage(errorCode :String, errorMessage :String) {
        if errorCode == "00" {
            let alertController = UIAlertController(title: "Status : \(errorCode)", message: errorMessage, preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: {(alert: UIAlertAction!) in
                //                self.dismiss(animated: true, completion: nil)
                self.closePage(self)
            }))
            present(alertController, animated: true, completion: nil)
            
        } else {
            var errMsg = errorMessage;
            if errorCode.starts(with: "9980") {
                errMsg = "\(errMsg) - Could not connect to server"
            } else if errorCode.starts(with: "9981") {
                errMsg = "\(errMsg) - Invalid Server Certificate"
            } else if errorCode.starts(with: "9983")  {
                errMsg = "\(errMsg) - VGuard Jailbroken detected"
            } else if errorCode.starts(with: "9984")  {
                errMsg = "\(errMsg) - VGuard SSL error detected"
            } else if errorCode.starts(with: "9985")  {
                errMsg = "\(errMsg) - VGuard Status error"
            } else if errorCode.starts(with: "9986")  {
                errMsg = "\(errMsg) - VGuard VOS error"
            } else if errorCode.starts(with: "9987")  {
                errMsg = "\(errMsg) - VGuard finished with error"
            } else if errorCode == "9988" {
                errMsg = "\(errMsg) - VGuard exception occured"
            } else if errorCode == "9989" {
                errMsg = "\(errMsg) - No token available"
            } else if errorCode == "9990" {
                errMsg = "\(errMsg) - VGuard Runtime Tampering Detected"
            } else if errorCode == "9991" {
                errMsg = "\(errMsg) - VGuard App Tampering Detected"
            } else if errorCode == "9992" {
                errMsg = "\(errMsg) - User Cancel"
            } else if errorCode == "9993" {
                errMsg = "\(errMsg) - SKB Error"
            } else if errorCode == "9994" {
                errMsg = "\(errMsg) - Invalid Transaction Cryptogram"
            } else if errorCode == "9995" {
                errMsg = "\(errMsg) - Missing Required Data"
            } else if errorCode == "9996" {
                errMsg = "\(errMsg) - Invalid Response from Server"
            } else if errorCode == "9997" {
                errMsg = "\(errMsg) - Error when generate Txn Data"
            } else if errorCode == "9998" {
                errMsg = "\(errMsg) - Pin Encryption error"
            } else if errorCode == "9999" {
                errMsg = "\(errMsg) - Unknown Error"
            }
            let alertController = UIAlertController(title: "Error : \(errorCode)", message: errMsg, preferredStyle: .alert)
            
            if (errorCode == "9987 - 20035") {
                NofService.main().clearVOS()
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { (action) in
//                    exit(1)
                }))
            } else {
                alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            }
            present(alertController, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func openSideMenu(_ sender: Any) {
        self.view.endEditing(true)
        //        if menuShowing {
        //            leadingConstraint.constant = -208
        //        } else {
        //            leadingConstraint.constant = 0
        //            UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseIn, animations: {
        //                self.view.layoutIfNeeded()
        //            }) { (completed) in
        //                // not used
        //            }
        //
        //        }
        //        menuShowing = !menuShowing
    }
    
    func showLoading() {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
    }
    
    func hideLoading() {
        dismiss(animated: true, completion: nil)
    }
    
    func getDataFromDB(keyName: String) -> String {
        let defaults = UserDefaults.standard
        let strData = defaults.string(forKey: keyName) ?? ""
        return strData
    }
    
    func storeDataToDB(keyValue: String, keyName: String) {
        let defaults = UserDefaults.standard
        defaults.set(keyValue, forKey: keyName)
        defaults.synchronize()
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if let navController = segue.destination as? UINavigationController {
            if let viewController = navController.viewControllers.first as? BookingComfortViewController {
                guard let muidStr = self.txtMuid.text else {
                    return
                }
                print("muid = \(muidStr)")
                viewController.muid = muidStr
            }
        }
    }
    
    func dismissView() {
        self.registerSuccessView!.view.removeFromSuperview()
        self.closePage(self)
    }
    
}
